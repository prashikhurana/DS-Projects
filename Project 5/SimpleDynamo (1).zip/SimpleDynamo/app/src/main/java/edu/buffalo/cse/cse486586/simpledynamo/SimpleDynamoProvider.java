package edu.buffalo.cse.cse486586.simpledynamo;

import java.io.PrintWriter;
import java.net.SocketTimeoutException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Formatter;
import java.net.InetSocketAddress;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.net.Uri;

import android.util.Log;
import android.telephony.TelephonyManager;
import android.content.Context;

import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;
import java.net.ConnectException;
import java.net.InetAddress;
import android.database.MatrixCursor;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.regex.Pattern;

import java.util.*;

import android.util.AtomicFile;
import java.util.concurrent.ConcurrentHashMap;


public class SimpleDynamoProvider extends ContentProvider {

	static final String E_0 = "5554";
	static final String E_1 = "5556";
	static final String E_2 = "5558";
	static final String E_3 = "5560";
	static final String E_4 = "5562";

	static final String R_0 = "11108";
	static final String R_1 = "11112";
	static final String R_2 = "11116";
	static final String R_3 = "11120";
	static final String R_4 = "11124";

	static final int SERVER_PORT = 10000;
	static final String insertString = "INSERT";
	static final String queryString = "QUERY";
	static final String deleteString = "DELETE";
	static final String ClientThread = "ClientThread";
	static final String ServerThread = "ServerThread";
	static final String ContentProviderString = "ContentProvider";
	static final String addAndUpdateNodeToPortsListString = "Add and update";
	static final String queryOriginTrace = "QueryOrigin";

	private static final String KEY_FIELD = "key";
	private static final String VALUE_FIELD = "value";
	private static final String test = "test";
	private static final String x = "x";
	private boolean isNodeRecovered = false;
	private boolean isServerThread = false;
	//private volatile String nodeFailed = "";

	ConcurrentHashMap<String, String> localAllMsg = new ConcurrentHashMap<String, String>();
	ConcurrentHashMap<String, String> alldump = new ConcurrentHashMap<String, String>();
	ConcurrentHashMap<String, Boolean> getLocalDumpFrom = new ConcurrentHashMap<String, Boolean>();
	List<String> allAlivePorts = Collections.synchronizedList(new ArrayList<String>());

	ConcurrentHashMap<String,String> pred1map = new ConcurrentHashMap<String, String>();
	ConcurrentHashMap<String,String> pred2map = new ConcurrentHashMap<String, String>();
	ConcurrentHashMap<String,String> succ1map = new ConcurrentHashMap<String, String>();
	ConcurrentHashMap<String,String> succ2map = new ConcurrentHashMap<String, String>();
	ConcurrentHashMap<String, Boolean> getPredAndSucc = new ConcurrentHashMap<String, Boolean>();



	String me = "";
	String pred = "";
	String succ1 = "";
	String succ2 = "";

	String myPortGlobal = "";
	String myPortStr = "";
	String myPortHash = "";

	String valueReturnQ = "";
	String queryOrigin = "";

	private Uri buildUri(String scheme, String authority) {
		Uri.Builder uriBuilder = new Uri.Builder();
		uriBuilder.authority(authority);
		uriBuilder.scheme(scheme);
		return uriBuilder.build();
	}

	Uri mUri = buildUri("content", "edu.buffalo.cse.cse486586.simpledynamo.provider");

	Boolean isBaseNodeOperable = Boolean.FALSE;




	@Override
	public int delete(Uri uri, String selection, String[] selectionArgs){
// TODO Auto-generated method stub
		String key = selection;
		try {
			String loc = getLocationToUse(key, insertString);
			List<String> locationsPossible = new ArrayList<String>();
			locationsPossible.add(getPortFromEmulator(loc));
			locationsPossible.add(getPortFromEmulator(getsucc1(loc)));
			locationsPossible.add(getPortFromEmulator(getsucc2(loc)));

			Log.v("Locations Possible:key", key + locationsPossible.get(0) + " " + locationsPossible.get(1) + " " + locationsPossible.get(2));

			if (locationsPossible.contains(myPortGlobal)) {
				localAllMsg.remove(key);
				locationsPossible.remove(myPortGlobal);
			}

			for (int i = 0; i < locationsPossible.size(); i++) {
				String x = locationsPossible.get(i);
				Node n1 = new Node((key), "", "deletedirect", "", isBaseNodeOperable, "", "");
				Thread t = getClientThread(n1, x);
				t.start();
			}

			SharedPreferences pref = this.getContext().getSharedPreferences("MyPref", 0);
			SharedPreferences.Editor editor = pref.edit();
			editor.putString("LocalMessage", localAllMsg.toString());
			editor.commit();

		}catch (NoSuchAlgorithmException e){

		}

		return 0;
	}

	@Override
	public String getType(Uri uri) {
// TODO Auto-generated method stub
		return null;
	}

	@Override
	public  Uri insert(Uri uri, ContentValues values) {
		String key = values.getAsString(KEY_FIELD);
		String value = values.getAsString(VALUE_FIELD);
		//synchronized (this){
		try {

			String loc = getLocationToUse(key, insertString);
			List<String> locationsPossible = new ArrayList<String>();
			locationsPossible.add(getPortFromEmulator(loc));
			locationsPossible.add(getPortFromEmulator(getsucc1(loc)));
			locationsPossible.add(getPortFromEmulator(getsucc2(loc)));

			Log.v("Locations Possible:key", key+locationsPossible.get(0)+" "+locationsPossible.get(1)+" "+locationsPossible.get(2));

			if (locationsPossible.contains(myPortGlobal)){
				localAllMsg.put(key, value);
				locationsPossible.remove(myPortGlobal);
			}

			for (int i = 0; i < locationsPossible.size(); i++) {
				String x = locationsPossible.get(i);
				Node n1 = new Node((key), value, "insertdirect", "", isBaseNodeOperable, "", "");
				Thread t = getClientThread(n1, x);
				t.start();
			}

			SharedPreferences pref = this.getContext().getSharedPreferences("MyPref", 0);
			SharedPreferences.Editor editor = pref.edit();
			editor.putString("LocalMessage", localAllMsg.toString());
			editor.commit();

		} catch (NoSuchAlgorithmException e) {
			Log.v(ContentProviderString, "NO Such algo");
		}
		//}

		//Log.v("insert", values.toString());
		return null;
	}

	@Override
	public boolean onCreate() {
		TelephonyManager tel = (TelephonyManager)this.getContext().getSystemService(Context.TELEPHONY_SERVICE);
		String portStr = tel.getLine1Number().substring(tel.getLine1Number().length()-4);
		final String myPort = String.valueOf(Integer.parseInt(portStr)*2);
		me = portStr;
		pred = getPred(me);
		succ1 = getsucc1(me);
		succ2 = getsucc2(me);
		myPortGlobal = myPort;
		myPortStr = portStr;

		allAlivePorts.add(E_0);
		allAlivePorts.add(E_1);
		allAlivePorts.add(E_2);
		allAlivePorts.add(E_3);
		allAlivePorts.add(E_4);
		Log.v("My port is:",myPort+"Port Str:"+portStr);


		try {
			myPortHash = genHash(portStr);
			Log.v(ContentProviderString,"Creating a server thread");
			Thread t1 = getServerThread(new ServerSocket(SERVER_PORT));
			t1.start();

		}catch (Exception e){
			e.printStackTrace();
			isServerThread = true;
			Log.v("Exception","While Creating Server Thread");
		}

		if (localAllMsg.isEmpty()){
			Log.v("LOCAL MSG","IS empty");
		}else{
			Log.v("LOCAL MSG",localAllMsg.toString());
		}

		SharedPreferences failCheck = this.getContext().getSharedPreferences("failCheck",0);
      	if (failCheck.getBoolean("initialStartUp", true)){
      		Log.v("FAIL CHECK",""+isNodeRecovered);
         	failCheck.edit().putBoolean("initialStartUp",false).commit();
      	}else{
         	isNodeRecovered = true;
      	}


      // TODO Auto-generated method stub


      	if (isNodeRecovered) {
			//synchronized (this) {
				Log.v("isNodeRecovered", "" + isNodeRecovered);

				if (isServerThread) {
					Log.v("OnCreate","ServerThread"+isServerThread);
					Log.v("onCreate", "Getting the local message");
					SharedPreferences pref = this.getContext().getSharedPreferences("MyPref", 0);
					String x = pref.getString("LocalMessage", null);
					Log.v("X", "The value here is:" + x);
					if (x == null) {
						//Log.v("Did not find Local","Message");
					}
					if (x != null && x != "") {
						localAllMsg = getlocalmapdumpPred(x);
					}
				}

				//else{
					Log.v("OnCreate","ServerThread"+isServerThread);
					String pred1 = getPortFromEmulator(getPred(me));
					String pred2 = getPortFromEmulator(getPred2(me));
					String succ1 = getPortFromEmulator(getsucc1(me));
					String succ2 = getPortFromEmulator(getsucc2(me));


					getPredAndSucc.put(pred1, Boolean.FALSE);
					getPredAndSucc.put(pred2, Boolean.FALSE);
					getPredAndSucc.put(succ1, Boolean.FALSE);
					getPredAndSucc.put(succ2, Boolean.FALSE);

					long start_time = System.currentTimeMillis();
					long wait_time = 1000;
					long end_time = start_time + wait_time;

					while (!getPredAndSucc.get(pred1) && !getPredAndSucc.get(pred1) && !getPredAndSucc.get(pred1) && !getPredAndSucc.get(pred1) && System.currentTimeMillis()<end_time) {
						for (Map.Entry<String, Boolean> entry : getPredAndSucc.entrySet()) {
							String key = entry.getKey();
							Log.v("ONCREATE", key);
							Boolean valReq = Boolean.FALSE;
							while (!getPredAndSucc.get(key)) {
								//Log.v("INSIDE WHILE","Key:"+key+""+getPredAndSucc.get(key));
								if (!valReq) {
									if (key.equals(pred1)) {
										Node n1 = new Node("", "", "Pred1Replica", "", isBaseNodeOperable, "", getPortFromEmulator(me));
										//Log.v("check port", getPortFromEmulator(getPred(me)));
										//Log.v("INSIDE VALREQ","Key:PRED1"+pred1+""+valReq);
										Thread t = getClientThread(n1, key);
										t.start();
									} else if (key.equals(pred2)) {
										//pred2
										//Log.v("RECOVER PRED2",getPred2(me));
										Node n2 = new Node("", "", "Pred2Replica", "", isBaseNodeOperable, "", getPortFromEmulator(me));
										//Log.v("check port", getPortFromEmulator(getPred2(me)));
										Thread t2 = getClientThread(n2, key);
										//Log.v("INSIDE VALREQ","Key:PRED2"+pred1+""+valReq);
										t2.start();
									} else if (key.equals(succ1)) {
										//GET DATA FROM SUCC TO GET MISSING KEYS
										//succ1
										//Log.v("RECOVER SUCC1",getsucc1(me));
										Node n3 = new Node("", "", "Succ1Replica", "", isBaseNodeOperable, "", getPortFromEmulator(me));
										//Log.v("check port", getPortFromEmulator(getsucc1(me)));
										//Log.v("INSIDE VALREQ","Key:SUCC1"+succ1+""+valReq);
										Thread t3 = getClientThread(n3, key);
										t3.start();
									} else if (key.equals(succ2)) {
										Node n4 = new Node("", "", "Succ2Replica", "", isBaseNodeOperable, "", getPortFromEmulator(me));
										//Log.v("check port", getPortFromEmulator(getsucc2(me)));
										//Log.v("INSIDE VALREQ", "Key:SUCC1" + succ2 + "" + valReq);
										Thread t4 = getClientThread(n4, key);
										t4.start();
									}
								}
								valReq = Boolean.TRUE;
							}

						}

						mergeLocalMapWithSucc();
					}
				//}
			//}

      	}

		return false;
	}

	@Override
	public  Cursor query(Uri uri, String[] projection, String selection,
						 String[] selectionArgs, String sortOrder) {
		Log.v("In Query Function : ",myPortGlobal);
		//Log.v("Selection is",selection);
		MatrixCursor cursorz = new MatrixCursor(new String[]{KEY_FIELD,VALUE_FIELD});
		//queryString = queryString + " KEY is: " + selection;
		synchronized (this) {
			try {
				if (selection.equals("@")) {
					//get local partition
					Map<String, String> map = localAllMsg;
					for (Map.Entry<String, String> entry : map.entrySet()) {
						String key = entry.getKey();
						String value = entry.getValue();
						cursorz.addRow(new String[]{key, value});
					}
					Log.v(queryString,"For Port"+myPortGlobal+"LOCAL MAP"+localAllMsg.toString());
					queryOrigin = "";
					valueReturnQ = "";
					return cursorz;
				} else if (selection.equals("*")) {
					for (Map.Entry<String, String> entry : localAllMsg.entrySet()) {
						String key = entry.getKey();
						String value = entry.getValue();
						alldump.put(key, value);
					}

					//Find FailedNode and Remove it from allAlivePorts

					for (int i = 0; i < allAlivePorts.size(); i++) {
						String pi = getPortFromEmulator(allAlivePorts.get(i));
						getLocalDumpFrom.put(pi, Boolean.FALSE);
					}

					for (int i = 0; i < allAlivePorts.size(); i++) {
						Log.v(queryString, "4");
						String pi = getPortFromEmulator(allAlivePorts.get(i));
						if (!pi.equals(myPortGlobal)) {
							Log.v(queryString, "5");
							long start_time = System.currentTimeMillis();
							long wait_time = 100;
							long end_time = start_time + wait_time;
							Boolean valReq = Boolean.FALSE;
							while (getLocalDumpFrom.containsKey(pi) && !getLocalDumpFrom.get(pi) && System.currentTimeMillis()<end_time) {
								//Log.v(queryString,"8");
								if (!valReq) {
									Log.v(queryString, "9");
									Node n2 = new Node((selection), "", "giveLocalDump", "", isBaseNodeOperable, "", myPortGlobal);
									Thread t1 = getClientThread(n2, pi);
									t1.start();
								}
								valReq = Boolean.TRUE;
							}
						}
					}
					Log.v(queryString, "dumping all");
					//getting all the dump to the cursor set
					for (Map.Entry<String, String> entry : alldump.entrySet()) {
						String key = entry.getKey();
						String value = entry.getValue();
						cursorz.addRow(new String[]{key, value});
					}
					queryOrigin = "";
					valueReturnQ = "";
					return cursorz;
				} else {
					try {
						Log.v(queryString, " KEY is: " + selection + " VALUE RET: " + valueReturnQ + " ORIGINQ" + queryOrigin + " MY PORT: " + myPortGlobal);
						String key = selection;
						String loc = getLocationToUse(key, queryString);
						List<String> locationsPossible = new ArrayList<String>();
						locationsPossible.add(getPortFromEmulator(loc));
						locationsPossible.add(getPortFromEmulator(getsucc1(loc)));
						locationsPossible.add(getPortFromEmulator(getsucc2(loc)));

						//find failedNode and remove From Location Possible


						//Log.v("Query","The failed Node"+nodeFailed);
						Log.v("Location is in query:",locationsPossible.get(0)+" or "+locationsPossible.get(1));

						if (localAllMsg.containsKey(selection)) {
							if (queryOrigin.equals("")) {
								queryOrigin = myPortGlobal;
							}
							//Log.v(queryString, "KEY IS: " + selection + "From : 6");
							if (queryOrigin.equals(myPortGlobal)) {
								//Log.v(queryString, "KEY IS: " + selection + "From : 7");
								valueReturnQ = localAllMsg.get(selection);
							}else if (!queryOrigin.equals(myPortGlobal)) {
								Log.v(queryString, "KEY IS: " + selection + "From : 8");
								Node n2 = new Node((selection), localAllMsg.get(selection), "returnQuery", "", isBaseNodeOperable, "", queryOrigin);
								Thread t2 = getClientThread(n2, queryOrigin);
								t2.start();
							}
						} else if (!localAllMsg.containsKey(selection)) {
							Log.v(queryString, "KEY IS: " + selection + "From : 1");
							for (int i=0;i<locationsPossible.size();i++) {
								long start_time = System.currentTimeMillis();
								long wait_time = 1000;
								long end_time = start_time + wait_time;
								Boolean valuRequested = Boolean.FALSE;
								//Log.v(queryString, "KEY IS: " + selection + "From : 2");
								//Log.v(queryString,"NODE FAIL"+this.nodeFailed);
								while (valueReturnQ.equals("") && System.currentTimeMillis() < end_time) {
									//Log.v(queryString,"KEY IS: "+selection + "From : 3");
									if (!valuRequested) {
										//Log.v(queryString, "Key is:" + selection + "In Port: " + myPortGlobal + " frwd to succ:" + getPortFromEmulator(loc));
										if (queryOrigin.equals("")) {
											queryOrigin = getPortFromEmulatorHash(myPortHash);
										}
										//Log.v(queryString, " Key: " + selection + " QUERY ORIGIN" + queryOrigin);
										Node n1 = new Node((selection), "", "query", "", isBaseNodeOperable, "", queryOrigin);
										Thread t1 = getClientThread(n1, locationsPossible.get(i));
										t1.start();
									} /*else {
										//Log.v(queryString,"KEY IS: "+selection + "From : 4");
										if (!queryOrigin.equals(myPortGlobal)) {
											//Log.v(queryString, "KEY IS: " + selection + "From : 5");
											break;
										}
									}*/
									valuRequested = Boolean.TRUE;
								}
								if (!valueReturnQ.equals("")){
									break;
								}
							}
						}

						Log.v(queryString, "Key"+key +" FINAL QUERY ORIGIN: " + queryOrigin + " VALUE RETURN Q:" + valueReturnQ);
						cursorz.addRow(new String[]{selection, valueReturnQ});
						queryOrigin = "";
						valueReturnQ = "";
						//nodeFailed = "";

					} catch (Exception e) {
						e.printStackTrace();
						Log.v("QUerying data", "Q");
						cursorz.addRow(new String[]{selection, "N/A"});
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return cursorz;
		// TODO Auto-generated method stub
	}

	@Override
	public int update(Uri uri, ContentValues values, String selection,
					  String[] selectionArgs) {
// TODO Auto-generated method stub
		return 0;
	}

	private String genHash(String input) throws NoSuchAlgorithmException {
		MessageDigest sha1 = MessageDigest.getInstance("SHA-1");
		byte[] sha1Hash = sha1.digest(input.getBytes());
		Formatter formatter = new Formatter();
		for (byte b : sha1Hash) {
			formatter.format("%02x", b);
		}
		return formatter.toString();
	}

	public class CreateServerSocketRunnable implements Runnable{
		ServerSocket s1;

		CreateServerSocketRunnable(ServerSocket s2){
			Log.v(ServerThread,"In CreateServerSocketRunnable");
			this.s1 = s2;
		}

		public void run() {
			//synchronized (x) {
			try {
				Node inputte = null;
				String ainput;

				while (true) {
					ServerSocket serverSocket = s1;
					//Log.v(ServerThread, "in while true");
					Socket socket = serverSocket.accept();
					//Log.v(ServerThread, "Got socket");
					ObjectInputStream ois = new ObjectInputStream(socket.getInputStream());
					//Log.v(ServerThread, "Read input stream");
					ainput = (String) ois.readObject();
					String[] inputarr = ainput.split(";");
					Log.v(ServerThread, "AINPUT:"+ainput+"Length od inputarr"+inputarr.length);
					//msg.getKey()+";"+msg.getValue()+";"+msg.getAction()+";"+msg.getQueryValue()+";"+msg.getStartNode()+";"+msg.getJoinNode());

					String keyx = "";
					String valuex = "";
					String actionx = "";
					String joinNodex = "";
					String queryValue = "";
					String startNodeForQuery = "";
					if (inputarr.length == 3){
						if (inputarr[0]!=null) {
							keyx = (inputarr[0]);
						}
						if (inputarr[1]!=null) {
							valuex = (inputarr[1]);
						}
						if (inputarr[2]!=null) {
							actionx = (inputarr[2]);
						}
					}
					if (inputarr.length == 4){
						if (inputarr[0]!=null) {
							keyx = (inputarr[0]);
						}
						if (inputarr[1]!=null) {
							valuex = (inputarr[1]);
						}
						if (inputarr[2]!=null) {
							actionx = (inputarr[2]);
						}
						if (inputarr[3]!=null){
							queryValue = inputarr[3];
						}
					}
					if (inputarr.length==5) {
						if (inputarr[0]!=null) {
							keyx = (inputarr[0]);
						}
						if (inputarr[1]!=null) {
							valuex = (inputarr[1]);
						}
						if (inputarr[2]!=null) {
							actionx = (inputarr[2]);
						}
						if (inputarr[3]!=null){
							queryValue = inputarr[3];
						}
						if (inputarr[4]!=null){
							startNodeForQuery = inputarr[4];
						}
					}
					if (inputarr.length==6){
						if (inputarr[0]!=null) {
							keyx = (inputarr[0]);
						}
						if (inputarr[1]!=null) {
							valuex = (inputarr[1]);
						}
						if (inputarr[2]!=null) {
							actionx = (inputarr[2]);
						}
						if (inputarr[3]!=null){
							queryValue = inputarr[3];
						}
						if (inputarr[4]!=null){
							startNodeForQuery = inputarr[4];
						}
						if (inputarr[5]!=null) {
							joinNodex = inputarr[5];
						}
					}
					inputte = new Node(keyx, valuex, actionx,joinNodex, isBaseNodeOperable,queryValue,startNodeForQuery);
					if (inputte == null) {
						Log.v(ServerThread,"Inputte is null");
						break;
					}
					if (inputte.getAction().equals("insertdirect")){
						synchronized (localAllMsg) {
							String key = inputte.getKey();
							String val = inputte.getValue();
							Log.v(ServerThread,"For key:"+key+" val:"+val);
							localAllMsg.put(key, val);
							SharedPreferences pref = getContext().getSharedPreferences("MyPref", 0);
							SharedPreferences.Editor editor = pref.edit();
							editor.putString("LocalMessage", localAllMsg.toString());
							editor.commit();
						}
					}

					Log.v(ServerThread, "The action is: " + inputte.getAction());
					if (inputte.getAction().equals("insert")) {
						Log.v(ServerThread, "Insert");
						String key = inputte.getKey();
						String val = inputte.getValue();
						ContentValues cv = new ContentValues();
						cv.put(KEY_FIELD,key);
						cv.put(VALUE_FIELD,val);
						Log.v(insertString,"Inserting in:"+myPortGlobal+"Key :"+key+"Value :"+val);
						insert(mUri,cv);
					}
					if (inputte.getAction().equals("query")) {
						String queryOrigin1 = startNodeForQuery;
						if (localAllMsg.containsKey(keyx)){
							Node n2 = new Node((keyx), localAllMsg.get(keyx), "returnQuery", myPortGlobal, isBaseNodeOperable, "", queryOrigin1);
							Thread t2 = getClientThread(n2, queryOrigin1);
							t2.start();
						}
					}
					if (inputte.getAction().equals("returnQuery")){
						if (valueReturnQ.equals("")) {
							queryOrigin = myPortGlobal;
							valueReturnQ = valuex;
						}
					}

					if (inputte.getAction().equals("giveLocalDump")){
						Log.v(ServerThread,"10");
						queryOrigin = startNodeForQuery;
						String localDumpMap = "";
						localDumpMap = localAllMsg.toString();
						Node nn = new Node("", "", "takeLocalDump", localDumpMap, isBaseNodeOperable, "", myPortGlobal);
						Thread t4 = getClientThread(nn, queryOrigin);
						t4.start();
						queryOrigin = "";
					}
					if (inputte.getAction().equals("takeLocalDump")){
						Log.v(ServerThread,"11");
						String gotFromQuery = startNodeForQuery;
						Log.v(ServerThread,"This query Dump: "+gotFromQuery + "Join Node" + inputte.getJoinNode().length());
						if (!inputte.getJoinNode().equals("")) {
							ConcurrentHashMap<String, String> newLocalDump = getlocalmapdumpPred(inputte.getJoinNode());
							for (Map.Entry<String, String> entry : newLocalDump.entrySet()) {
								String key = entry.getKey();
								String value = entry.getValue();
								alldump.put(key, value);
							}
						}
						getLocalDumpFrom.put(gotFromQuery,Boolean.TRUE);
						queryOrigin = "";
					}
					if (inputte.getAction().equals("delete")){
						delete(mUri, keyx,null);;
					}
					if(inputte.getAction().equals("deletedirect")){
						localAllMsg.remove(keyx);
						SharedPreferences pref = getContext().getSharedPreferences("MyPref", 0);
						SharedPreferences.Editor editor = pref.edit();
						editor.putString("LocalMessage", localAllMsg.toString());
						editor.commit();
					}

					if (inputte.getAction().equals("Pred1Replica")){
						String squeryOrigin = startNodeForQuery;
						Log.v(ServerThread,"Giving Pred  1/2 Replica to:"+squeryOrigin);
						//String localDumpMap = localAllMsg.toString();
						String localDumpMap = "";
						try {
							localDumpMap = (getRecoveryValuesFromPred1(squeryOrigin).toString());
							//nodeFailed = squeryOrigin;
						}catch (NoSuchAlgorithmException e){
							e.printStackTrace();
						}
						Node nn = new Node("", "", "takePred1Replica", localDumpMap, isBaseNodeOperable, "", myPortGlobal);
						Thread t4 = getClientThread(nn, squeryOrigin);
						t4.start();
					}

					if (inputte.getAction().equals("takePred1Replica") ){
						Log.v(ServerThread,"Getting Pred 1 Replica");
						String gotFromQuery = startNodeForQuery;
						Log.v(ServerThread,"This query Pred: "+gotFromQuery + "Join Node" + inputte.getJoinNode().length());
						if (!inputte.getJoinNode().equals("")) {
							pred1map = getlocalmapdumpPred(inputte.getJoinNode());
							getPredAndSucc.put(gotFromQuery,true);
						}

						//mergeLocalMapWithSucc();
					}

					if (inputte.getAction().equals("Pred2Replica")){
						String squeryOrigin = startNodeForQuery;
						Log.v(ServerThread,"Giving Pred 2 Replica to:"+squeryOrigin);
						String localDumpMap = "";
						try {
							localDumpMap = (getRecoveryValuesFromPred2(squeryOrigin).toString());
							//nodeFailed = squeryOrigin;
						}catch (NoSuchAlgorithmException e){
							e.printStackTrace();
						}
						Log.v("Local Map Pred",""+localAllMsg.keySet().size());
						Node nn = new Node("", "", "takePred2Replica", localDumpMap, isBaseNodeOperable, "", myPortGlobal);
						Thread t4 = getClientThread(nn, squeryOrigin);
						t4.start();
					}

					if (inputte.getAction().equals("takePred2Replica")){
						Log.v(ServerThread,"Getting Pred 2 Replica");
						String gotFromQuery = startNodeForQuery;
						Log.v(ServerThread,"This query Pred: "+gotFromQuery + "Join Node" + inputte.getJoinNode().length());
						if (!inputte.getJoinNode().equals("")) {
							pred2map = getlocalmapdumpPred(inputte.getJoinNode());
							getPredAndSucc.put(gotFromQuery,true);
						}

						//mergeLocalMapWithSucc();
					}

					if (inputte.getAction().equals("Succ1Replica") ){
						//Log.v(ServerThread,"Succ 1 Replica");
						String squeryOrigin = startNodeForQuery;
						Log.v(ServerThread,"Giving Succ1 Replica to:"+squeryOrigin);
						String localDumpMap = "";
						try {
							localDumpMap = (getRecoveryValuesFromSucc(squeryOrigin).toString());
							//nodeFailed = squeryOrigin;
						}catch (NoSuchAlgorithmException e){
							e.printStackTrace();
						}
						Node nn = new Node("", "", "takeSucc1Replica", localDumpMap, isBaseNodeOperable, "", myPortGlobal);
						Thread t4 = getClientThread(nn, squeryOrigin);
						t4.start();
					}

					if (inputte.getAction().equals("takeSucc1Replica") ){
						Log.v(ServerThread,"Succ 1 Replica Take");
						String gotFromQuery = startNodeForQuery;
						Log.v(ServerThread,"This query Succ: "+gotFromQuery + "Join Node" + inputte.getJoinNode().length());
						if (!inputte.getJoinNode().equals("")) {
							succ1map = getlocalmapdumpPred(inputte.getJoinNode());
							getPredAndSucc.put(gotFromQuery,true);
						}
						//mergeLocalMapWithSucc();
					}

					if (inputte.getAction().equals("Succ2Replica")){
						//Log.v(ServerThread,"Succ 2 Replica");
						String squeryOrigin = startNodeForQuery;
						Log.v(ServerThread,"Giving SUcc 2 Replica to:"+squeryOrigin);
						String localDumpMap = "";
						try {
							localDumpMap = (getRecoveryValuesFromSucc(squeryOrigin).toString());
							//nodeFailed = squeryOrigin;
						}catch (NoSuchAlgorithmException e){
							e.printStackTrace();
						}
						Node nn = new Node("", "", "takeSucc2Replica", localDumpMap, isBaseNodeOperable, "", myPortGlobal);
						Thread t4 = getClientThread(nn, squeryOrigin);
						t4.start();
					}

					if (inputte.getAction().equals("takeSucc2Replica")){
						Log.v(ServerThread,"Succ 2 Replica Take");
						String gotFromQuery = startNodeForQuery;
						Log.v(ServerThread,"This query Pred: "+gotFromQuery + "Join Node" + inputte.getJoinNode().length());
						if (!inputte.getJoinNode().equals("")) {
							succ2map = getlocalmapdumpPred(inputte.getJoinNode());
							getPredAndSucc.put(gotFromQuery,true);
						}
						//mergeLocalMapWithSucc();
					}
					if (inputte.getAction().equals("checkForFailed")){
						Log.v(ServerThread, "CheckForFailed");
					}
				}
			}catch (IOException e){
				e.printStackTrace();
			}catch (ClassNotFoundException e){
				e.printStackTrace();
			}
			//}
		}
	}

	public Thread getClientThread(Node msg,String port){
		try {
			//Log.v(ClientThread, "getClientThread: " + msg.printSendNode() + "With Port: " + (port));
		}catch (Exception e){
			Log.v("No SUCh algo","Cl");
		}
		CLientScoketCreateRunnable scc4 = new CLientScoketCreateRunnable(new CLientSocketCreate(msg, port));
		Thread t1 = new Thread(scc4);
		return t1;
	}

	public class CLientScoketCreateRunnable implements Runnable{

		String msg;
		String port;
		CLientSocketCreate socket1 ;

		CLientScoketCreateRunnable(CLientSocketCreate socket){
			//Log.v("CLientScoketCreateRunn","In here");
			this.socket1 = socket;
		}

		public void run() {
			//Log.v("CLientScoketCreateRunn","In here trying to run the CLientSocketCreate send data");
			socket1.sendData();
		}
	}

	public class CLientSocketCreate {
		Node msg;
		String port;
		Socket s ;

		CLientSocketCreate(Node message, String ports) {
			msg = message;
			port = ports;
		}

		public void sendData() {
			synchronized (test) {
				try {
					if (port != null) {
						Log.v("Send data", msg.printSendNode() + "PORT: " + port);
						s = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}), Integer.parseInt(port));
						s.setSoTimeout(100);
						//Log.v("Here","Here");
						ObjectOutputStream oos1 = new ObjectOutputStream(s.getOutputStream());
						oos1.writeObject(msg.getKey()+";"+msg.getValue()+";"+msg.getAction()+";"+msg.getQueryValue()+";"+msg.getStartNode()+";"+msg.getJoinNode());
						oos1.close();
						s.close();
					}
				}catch (SocketTimeoutException e){
					//nodeFailed = port;
					Log.v("sendData", "SocketTimeoutException"+"Failedport"+port);
				}
				catch (IOException e){
					e.printStackTrace();
					//nodeFailed = port;
					Log.e("sendData", "Catch"+"IO");
				}
				catch (Exception e) {
					e.printStackTrace();
					//nodeFailed = port;
					Log.v("senddata","Exception e");
				}
			}
		}
	}

	public Thread getServerThread(ServerSocket serverSocket){
		Log.v(ServerThread,"getServerThread with a server socket");
		//CreateServerSocket s1 = new CreateServerSocket(serverSocket);
		CreateServerSocketRunnable sr1 = new CreateServerSocketRunnable(serverSocket);
		Thread t2 = new Thread(sr1);
		return t2;
	}

	public class Node{
		//private static final long serialVersionUID = 6128016096756071380L;
		String key = "";
		String value = "";
		String action = "";
		String joinNode = "";
		Boolean isAliveBase = Boolean.FALSE;
		String queryValue = "";
		String startNode = "";

		public Node(String key, String value, String action,String joinNode,Boolean isAliveBase, String queryValue, String startNode){
			this.key = key;
			this.value = value;
			this.action = action;
			this.joinNode = joinNode;
			this.isAliveBase = isAliveBase;
			this.queryValue = queryValue;
			this.startNode = startNode;
		}

		public String getNodeReadyToSend(){
			String msgToPrint = this.key+";"+this.value+";"+this.action+";"+this.joinNode;
			return  msgToPrint  ;
		}

		public String printSendNode(){
			String msgToPrint = "Key:"+this.key+";"+"Value:"+this.value+";"+"Action:"+ this.action+";"+"NodeJoin:"+this.joinNode+"QUeryOrigin"+this.startNode;
			return  msgToPrint  ;
			//allAlivePort+circularNode;
		}

		public String getKey(){
			return this.key;
		}

		public String getValue(){
			return this.value;
		}

		public String getAction(){
			return this.action;
		}

		public String getJoinNode(){
			return this.joinNode;
		}

		public String getQueryValue() {
			return queryValue;
		}

		public void setQueryValue(String queryValue) {
			this.queryValue = queryValue;
		}

		public String getStartNode() {
			return startNode;
		}

		public void setStartNode(String startNode) {
			this.startNode = startNode;
		}

		public void setKey(String key){
			this.key = key;
		}

		public void setValue(String value) {
			this.value = value;
		}

		public void setAction(String action) {
			this.action = action;
		}

		public void setJoinNode(String joinNode) {
			this.joinNode = joinNode;
		}
	}



	public String givelocalmapdump(){
		synchronized (localAllMsg) {
			String result = "";
			for (Map.Entry<String, String> entry : localAllMsg.entrySet()) {
				String key = entry.getKey();
				String value = entry.getValue();
				if (value!=null) {
					result = result + key + ":" + value + "@";
				}
			}
			Log.v("Local Map Dump", "givelocalmapdump"+result);
			return result;
		}
	}

	public ConcurrentHashMap<String,String> getlocalmapdumpPred(String text){
		ConcurrentHashMap<String,String> data = new ConcurrentHashMap<String, String>();
		Pattern p = Pattern.compile("[\\{\\}\\=\\, ]++");
		String[] split = p.split(text);
		for ( int i=1; i+2 <= split.length; i+=2 ){
			data.put( split[i], split[i+1] );
		}
		return data;
	}

	public ConcurrentHashMap<String,String> getlocalmapdump(String a){
		ConcurrentHashMap<String,String> x = new ConcurrentHashMap<String, String>();
		String[] keyvalPairs = a.split("@");
		for (int i=0;i<keyvalPairs.length;i++){
			String[] d = keyvalPairs[i].split(":");
			for (int j=0;j<d.length;j++){
				x.put(d[0],d[1]);
			}
		}
		Log.v("HashMap is:",x.toString());
		return x;
	}

	public void mergeLocalMapWithSucc() {
		synchronized (localAllMsg) {

			ConcurrentHashMap<String, List<String>> combine = new ConcurrentHashMap<String,List<String>>();
			Log.v("LocalMapWithSucc","In the function LocalMapWithSucc");
			Log.v("LocalMapWithSucc","Server Thread:"+isServerThread);

			//Log.v("mergeLocalMapWithSucc", "SUCC1 MAP" + "keys:" + succ1map.keySet().size());
			//Log.v("mergeLocalMapWithSucc", "SUCC2 MAP" + "keys:" + succ2map.keySet().size());
			//Log.v("mergeLocalMapWithSucc", "LOCAL MAP" + "local" + localAllMsg.keySet().size());

			//Log.v("mergeLocalMapWithSucc", "SUCC1 MAP" + "MAP:" + succ1map.toString());
			//Log.v("mergeLocalMapWithSucc", "SUCC2 MAP" + "MAP:" + succ2map.toString());
			//Log.v("mergeLocalMapWithSucc", "LOCAL MAP" + "MAP" + localAllMsg.toString());


			//Log.v("mergeLocalMapWithSucc", "PRED1 MAP" + "keys:" + pred1map.keySet().size());
			//Log.v("mergeLocalMapWithSucc", "PRED2 MAP" + "keys:" + pred2map.keySet().size());
			//Log.v("mergeLocalMapWithSucc", "PRED3 MAP" + "local" + localAllMsg.keySet().size());

			//Log.v("mergeLocalMapWithSucc", "PRED1 MAP" + "keys:" + pred1map.toString());
			//Log.v("mergeLocalMapWithSucc", "PRED2 MAP" + "keys:" + pred2map.toString());
			//Log.v("mergeLocalMapWithSucc", "PRED3 MAP" + "local" + localAllMsg.toString());

			//if (isServerThread) {
				if (!succ2map.isEmpty() && !succ1map.isEmpty()) {
					for (Map.Entry<String, String> entry : succ1map.entrySet()) {
						String key = entry.getKey();
						String value = entry.getValue();
						if (combine.containsKey(key)) {
							List<String> b = combine.get(key);
							b.add(value);
							combine.put(key, b);
						} else {
							List<String> b = new ArrayList<String>();
							b.add(value);
							combine.put(key, b);
						}
					}

					for (Map.Entry<String, String> entry : succ2map.entrySet()) {
						String key = entry.getKey();
						String value = entry.getValue();
						if (combine.containsKey(key)) {
							List<String> b = combine.get(key);
							b.add(value);
							combine.put(key, b);
						} else {
							List<String> b = new ArrayList<String>();
							b.add(value);
							combine.put(key, b);
						}
					}
				}

				if (!pred1map.isEmpty() && !pred2map.isEmpty()) {
					for (Map.Entry<String, String> entry : pred1map.entrySet()) {
						String key = entry.getKey();
						String value = entry.getValue();
						if (combine.containsKey(key)) {
							List<String> b = combine.get(key);
							b.add(value);
							combine.put(key, b);
						} else {
							List<String> b = new ArrayList<String>();
							b.add(value);
							combine.put(key, b);
						}
					}

					for (Map.Entry<String, String> entry : pred2map.entrySet()) {
						String key = entry.getKey();
						String value = entry.getValue();
						if (combine.containsKey(key)) {
							List<String> b = combine.get(key);
							b.add(value);
							combine.put(key, b);
						} else {
							List<String> b = new ArrayList<String>();
							b.add(value);
							combine.put(key, b);
						}
					}
				}
			//}

			if (!localAllMsg.isEmpty()){
				Log.v("MergeSucc","Local"+localAllMsg.toString());
				for (Map.Entry<String, String> entry : localAllMsg.entrySet()) {
					String key = entry.getKey();
					String value = entry.getValue();
					if (combine.containsKey(key)) {
						/*List<String> b = combine.get(key);
						b.add(value);
						combine.put(key, b);*/
						int m = 2;
					} else {
						List<String> b = new ArrayList<String>();
						b.add(value);
						combine.put(key, b);
					}
				}
			}


			localAllMsg.clear();
			if (!combine.isEmpty()){
				for (Map.Entry<String, List<String>> entry : combine.entrySet()) {
					String key = entry.getKey();
					List<String> value = entry.getValue();
					localAllMsg.put(key,finamax(key,value,value.size()));
				}
			}

			SharedPreferences pref = this.getContext().getSharedPreferences("MyPref", 0);
         	SharedPreferences.Editor editor = pref.edit();
         	editor.putString("LocalMessage", localAllMsg.toString());
         	editor.commit();

		}
	}


	public ConcurrentHashMap<String,String> getRecoveryMapAsStringFromSucc(String a){
		ConcurrentHashMap<String,String> x = new ConcurrentHashMap<String, String>();
		String[] keyvalPairs = a.split("@");
		for (int i=0;i<keyvalPairs.length;i++){
			String[] d = keyvalPairs[i].split(":");
			for (int j=0;j<d.length;j++){
				x.put(d[0],d[1]);
			}
		}
		Log.v("TakeRecoverMapDump:",x.toString());
		return x;
	}

	public ConcurrentHashMap<String,String> getRecoveryValuesFromPred1(String portNumber) throws NoSuchAlgorithmException{
		ConcurrentHashMap<String,String> x = new ConcurrentHashMap<String, String>();
		String predictedPort = getEmulatorFromPort(portNumber);
		Log.v("getRecoveryFromPred1","PREDICTED :"+predictedPort);
		for (Map.Entry<String, String> entry : localAllMsg.entrySet()) {
			String key = entry.getKey();
			String value = entry.getValue();
			String actualPort = getLocationToUse(key,"Pred1MapCreate");
			if (predictedPort.equals(getsucc1(actualPort))){
				x.put(key,value);
			}
		}
		return x;
	}

	public ConcurrentHashMap<String,String> getRecoveryValuesFromPred2(String portNumber) throws NoSuchAlgorithmException{
		ConcurrentHashMap<String,String> x = new ConcurrentHashMap<String, String>();
		String predictedPort = getEmulatorFromPort(portNumber);
		Log.v("getRecoveryFromPred2","PREDICTED :"+predictedPort);
		for (Map.Entry<String, String> entry : localAllMsg.entrySet()) {
			String key = entry.getKey();
			String value = entry.getValue();
			String actualPort = getLocationToUse(key,"Pred2MapCreate");
			if (predictedPort.equals(getsucc2(actualPort))){
				x.put(key,value);
			}
		}
		return x;
	}





	//given a map of values and a port, find if the key belongs in the port.
	public ConcurrentHashMap<String,String> getRecoveryValuesFromSucc(String portNumber) throws NoSuchAlgorithmException{
		ConcurrentHashMap<String,String> x = new ConcurrentHashMap<String, String>();
		for (Map.Entry<String, String> entry : localAllMsg.entrySet()) {
			Boolean insertInYouself = Boolean.FALSE;
			String key = entry.getKey();
			String value = entry.getValue();

			String kh = genHash(key);
			String mh = genHash(getEmulatorFromPort(portNumber));
			String ph = genHash(getPred(getEmulatorFromPort(portNumber)));

			if (ph.compareTo(mh) > 0) {
				if (kh.compareTo(ph) > 0 && kh.compareTo(mh) > 0) {
					insertInYouself = Boolean.TRUE;
				}
				if (kh.compareTo(ph) < 0 && kh.compareTo(mh) <= 0) {
					insertInYouself = Boolean.TRUE;
				}
			}
			if (kh.compareTo(ph) > 0 && kh.compareTo(mh) <= 0) {
				insertInYouself = Boolean.TRUE;
			}

			if (insertInYouself){
				//Log.v("getRecoveryValuesSucc","for key:"+key+"for port"+portNumber);
				x.put(key,value);
			}

		}
		return x;
	}

	public String finamax(String key,List<String> x, int n){
		//Log.v("findmax","The maximum out of all"+x.toString());
		String result = "";
		if(n==1){
			result = x.get(0);
		}else if (n==2){
			result = x.get(0);
		}else if (n==3) {
			HashMap<String, Integer> map = new HashMap<String, Integer>();
			for (int i = 0; i < n; i++) {
				if (map.containsKey(x.get(i))) {
					int count = map.get(x.get(i)) + 1;
					if (count > n / 2) {
						result = x.get(i);
						break;
					} else {
						map.put(x.get(i), 1);
					}
				} else {
					map.put(x.get(i), 1);
				}
			}
		}
		Log.v("findmax","Findmax"+"The maximum:"+result+"key:"+key+"all"+x.toString());
		return result;
	}



	public String getLocationToUse(String key, String use)throws  NoSuchAlgorithmException {
		String loc = "";
		use = use + " Key: " + key;

		Boolean sendToSucc = Boolean.FALSE;
		Boolean insertInYouself = Boolean.FALSE;

		for (int i = 0; i < allAlivePorts.size(); i++) {

			String kh = genHash(key);
			String mh = genHash(allAlivePorts.get(i));
			String ph = genHash(getPred(allAlivePorts.get(i)));

			if (ph.compareTo(mh) > 0) {
				if (kh.compareTo(ph) > 0 && kh.compareTo(mh) > 0) {
					//Log.v(use, "Set insert in yourself here 1");
					insertInYouself = Boolean.TRUE;
				}
				if (kh.compareTo(ph) < 0 && kh.compareTo(mh) <= 0) {
					//Log.v(use, "Set insert in yourself here 2");
					insertInYouself = Boolean.TRUE;
				}
			}
			if (kh.compareTo(ph) > 0 && kh.compareTo(mh) <= 0) {
				//Log.v(use, "Set insert in yourself here 3");
				insertInYouself = Boolean.TRUE;
			}

			if (insertInYouself) {
				loc = allAlivePorts.get(i);
				break;
			}
		}
		//Log.v("For key",key+"loc is"+getPortFromEmulator(loc));

		return loc;
	}

	public String getEmulatorFromPort(String a){
		String result = "";
		if (a.equals(R_2)){
			result = E_2;
		}
		if (a.equals(R_3)){
			result = E_3;
		}
		if (a.equals(R_4)){
			result = E_4;
		}
		if (a.equals(R_1)){
			result = E_1;
		}
		if (a.equals(R_0)){
			result = E_0;
		}
		return result;
	}

	public String getsucc1(String a){
		String result = "";
		if (a.equals(E_0)){
			result = E_2;
		}
		if (a.equals(E_2)){
			result = E_3;
		}
		if (a.equals(E_3)){
			result = E_4;
		}
		if (a.equals(E_4)){
			result = E_1;
		}
		if (a.equals(E_1)){
			result = E_0;
		}
		return result;
	}

	public String getsucc2(String a){
		String result = "";

		if (a.equals(E_0)){
			result = E_3;
		}
		if (a.equals(E_2)){
			result = E_4;
		}
		if (a.equals(E_3)){
			result = E_1;
		}
		if (a.equals(E_4)){
			result = E_0;
		}
		if (a.equals(E_1)){
			result = E_2;
		}
		return result;
	}

	public String getPred(String a){
		String result = "";
		if (a.equals(E_0)){
			result = E_1;
		}
		if (a.equals(E_1)){
			result = E_4;
		}
		if (a.equals(E_4)){
			result = E_3;
		}
		if (a.equals(E_3)){
			result = E_2;
		}
		if (a.equals(E_2)){
			result = E_0;
		}
		return result;
	}

	public String getPred2(String a){
		String result = "";
		if (a.equals(E_0)){
			result = E_4;
		}
		if (a.equals(E_1)){
			result = E_3;
		}
		if (a.equals(E_4)){
			result = E_2;
		}
		if (a.equals(E_3)){
			result = E_0;
		}
		if (a.equals(E_2)){
			result = E_1;
		}
		return result;
	}

	public String getPortFromEmulator(String a){
		String result = "";
		if (a.equals(E_0)){
			result = R_0;
		}
		if (a.equals(E_1)){
			result = R_1;
		}
		if (a.equals(E_2)){
			result = R_2;
		}
		if (a.equals(E_3)){
			result = R_3;
		}
		if (a.equals(E_4)){
			result = R_4;
		}
		return result;
	}

	public String getPortFromEmulatorHash(String a) throws NoSuchAlgorithmException{
		String result = "";
		if (genHash(E_0).equals(a)) {
			result = R_0;
		}
		if (genHash(E_1).equals(a)) {
			result = R_1;
		}
		if (genHash(E_2).equals(a)) {
			result = R_2;
		}
		if (genHash(E_3).equals(a)) {
			result = R_3;
		}
		if (genHash(E_4).equals(a)) {
			result = R_4;
		}
		return result;
	}
}