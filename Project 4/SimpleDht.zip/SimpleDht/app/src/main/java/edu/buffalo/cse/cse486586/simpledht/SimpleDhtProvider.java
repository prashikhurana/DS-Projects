package edu.buffalo.cse.cse486586.simpledht;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.math.BigInteger;
import java.net.ConnectException;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.acl.NotOwnerException;
import java.util.Formatter;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.telephony.TelephonyManager;
import android.util.AtomicFile;
import android.util.Log;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import android.content.ContentResolver;
import java.io.Serializable;

public class SimpleDhtProvider extends ContentProvider {

    static final String TAG = SimpleDhtActivity.class.getSimpleName();
    static final String ServerThread = "Server Thread";
    static final String ClientThread = "Client Thread";
    static final String ContentProviderString = "ContentProvider";
    static final String addInSortedOrderString = "addInSortedOrder";
    static final String addAndUpdateNodeToPortsListString = "addUpdateNodePortsList";
    static final String getPredForNodeString = "getPredForNode";
    static final String getSuccForNodeString = "getSuccForNode";
    static final String REMOTE_PORT0 = "11108";
    static final String REMOTE_PORT1 = "11112";
    static final String REMOTE_PORT2 = "11116";
    static final String REMOTE_PORT3 = "11120";
    static final String REMOTE_PORT4 = "11124";
    static final String R_0 = "5554";
    static final String R_1 = "5556";
    static final String R_2 = "5558";
    static final String R_3 = "5560";
    static final String R_4 = "5562";
    static final int SERVER_PORT = 10000;
    static final String insertString = "INSERT";
    static final String queryString = "QUERY";
    static final String deleteString = "DELETE";
    static final String test = "test";
    private static final String KEY_FIELD = "key";
    private static final String VALUE_FIELD = "value";
    List<String> allAlivePorts = Collections.synchronizedList(new ArrayList<String>());
    ConcurrentHashMap<String, Port> portList = new ConcurrentHashMap<String, Port>();
    ConcurrentHashMap<String, String> localAllMsg = new ConcurrentHashMap<String, String>();
    String myPortGlobal = "";
    //String myHashGlobal = "";
    String myPortStr = "";
    ArrayList<String> QueryPortList = new ArrayList<String>(5);
    Boolean isBaseNodeOperable = Boolean.FALSE;
    String queryOrigin = "";
    String valueReturnQ = "";
    Boolean foundValue = Boolean.FALSE;
    ConcurrentHashMap<String, String> alldump = new ConcurrentHashMap<String, String>();
    int count = 0;
    ConcurrentHashMap<String, Boolean> getLocalDumpFrom = new ConcurrentHashMap<String, Boolean>();
    Boolean deletedKey = Boolean.FALSE;

    Uri mUri = buildUri("content", "edu.buffalo.cse.cse486586.simpledht.provider");

    @Override
    public int delete(Uri uri, String selection, String[] selectionArgs) {
        // TODO Auto-generated method stub
        String key = selection;
        try {
            Port p1 = portList.get(genHash(myPortStr));
            if (allAlivePorts.size() == 1) {
                localAllMsg.remove(key);
            } else {
                /*if (localAllMsg.containsKey(key)){
                    localAllMsg.remove(key);
                }else {
                    Node n1 = new Node((key), "", "DELETEQuery", "", isBaseNodeOperable, "", "");
                    Thread t = getClientThread(n1, getPortFromEmulator(getEmulatorFromHash(p1.getSuccessor())));
                    t.start();
                }*/
                switch(getLocationToUse(p1,key,insertString)){
                    case 1:
                        //Log.v("Give to successor", "Insert");
                        Node n1 = new Node((key), "", "deletequery", "",isBaseNodeOperable,"","");
                        Thread t = getClientThread(n1, getPortFromEmulator(getEmulatorFromHash(p1.getSuccessor())));
                        t.start();
                        break;
                    case 3:
                        Log.v(insertString,"DELETE IN"+myPortGlobal+"DELETE:"+"key: "+(key));
                        localAllMsg.remove(key);
                        break;
                }
            }
        }catch (NoSuchAlgorithmException e){
            Log.v(ContentProviderString,"NO Such algo");
        }
        return 0;
    }

    @Override
    public String getType(Uri uri) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public Uri insert(Uri uri, ContentValues values) {
        // TODO Auto-generated method stub
        //Log.v(insertString,"Insert"+"Test");
        String key = values.getAsString(KEY_FIELD);
        String value = values.getAsString(VALUE_FIELD);

        //Log.v("In Insert Function","Test2");
        //printConcurrentHashMap();
        try {
            Port p1 = portList.get(genHash(myPortStr));
            //Log.v(insertString, "Key is: "+key+" Hash of key: "+genHash(key)+"My Port is: "+getEmulatorFromPort(myPortGlobal));
            //Log.v(insertString, "PRED IS: "+p1.getPredecessor()+" PRED PORT: "+getEmulatorFromHash(p1.getPredecessor()));
            //Log.v(insertString, "SUCC IS: "+p1.getSuccessor()+" SUCC PORT: "+getEmulatorFromHash(p1.getSuccessor()));

            switch(getLocationToUse(p1,key,insertString)){
                case 1:
                    //Log.v("Give to successor", "Insert");
                    Node n1 = new Node((key), value, "insert", "",isBaseNodeOperable,"","");
                    Thread t = getClientThread(n1, getPortFromEmulator(getEmulatorFromHash(p1.getSuccessor())));
                    t.start();
                    break;

                case 2:
                    //Log.v("Get from successor", " Insert");
                    Node n11 = new Node((key), value, " insert", "",isBaseNodeOperable,"","");
                    Thread t1 = getClientThread(n11, getPortFromEmulator(getEmulatorFromHash(p1.getPredecessor())));
                    t1.start();
                    break;
                case 3:
                    Log.v(insertString,"INSERT IN"+myPortGlobal+"INSERT:"+"value: "+value+"key: "+(key));
                    localAllMsg.put(key,value);
                    break;
            }
        }catch (NoSuchAlgorithmException e){
            Log.v(ContentProviderString,"NO Such algo");
        }

        //Log.v("insert", values.toString());
        return null;
    }

    @Override
    public boolean onCreate() {
        //Log.v(ContentProviderString,"onCreate()");
        TelephonyManager tel = (TelephonyManager)this.getContext().getSystemService(Context.TELEPHONY_SERVICE);
        String portStr = tel.getLine1Number().substring(tel.getLine1Number().length()-4);
        final String myPort = String.valueOf(Integer.parseInt(portStr)*2);
        myPortGlobal = myPort;
        myPortStr = portStr;
        Log.v("Emulator with Port",myPort);
        int flag = 0;
        Socket s = null;
        try {
            //myHashGlobal = genHash(myPortGlobal);
            Log.v(ContentProviderString,"The port recieved is: "+myPort+" Hash is: "+genHash(myPort));
            Log.v(ContentProviderString,"This new node is: "+portStr+" The Hash is: "+genHash(portStr));
            addInSortedOrder(genHash(myPort));
            addAndUpdateNodeToPortsList(genHash(myPort));

            Node n1 = new Node("", "", "join", genHash(myPort),isBaseNodeOperable,"","");
            Thread t1 = getClientThread(n1, REMOTE_PORT0);
            t1.start();

        }catch (NoSuchAlgorithmException e){
            Log.v(TAG,"Problem with Hashing");
        }

        try {
            Log.v(ContentProviderString,"Creating a server thread");
            Thread t1 = getServerThread(new ServerSocket(SERVER_PORT));
            t1.start();
        }catch (Exception e){
            e.printStackTrace();
            Log.v("Exception","While Creating Server Thread");
        }
        return false;
    }

    @Override
    public Cursor query(Uri uri, String[] projection, String selection, String[] selectionArgs,
            String sortOrder) {
        Log.v("In Query Function : ",myPortGlobal);
        //Log.v("Selection is",selection);
        MatrixCursor cursorz = new MatrixCursor(new String[]{KEY_FIELD,VALUE_FIELD});
        Port p1 = null;
        //queryString = queryString + " KEY is: " + selection;
        try{
            p1 = portList.get(genHash(myPortStr));
        }catch (NoSuchAlgorithmException e){

        }
        Boolean sendtoSucc = Boolean.FALSE;
        if (selection.equals("@")) {
            //get local partition
            Map<String, String>map = localAllMsg;
            for (Map.Entry<String, String> entry : map.entrySet()) {
                String key = entry.getKey();
                String value = entry.getValue();
                cursorz.addRow(new String[]{key, value});
            }
        }else if (selection.equals("*")) {

            //getting the dump from local and adding to the dump here
            if (allAlivePorts.size()==1) {
                for (Map.Entry<String, String> entry : localAllMsg.entrySet()) {
                    String key = entry.getKey();
                    String value = entry.getValue();
                    cursorz.addRow(new String[]{key, value});
                }
            }else {
                try {
                    Log.v(queryString,"1");
                    for (Map.Entry<String, String> entry : localAllMsg.entrySet()) {
                        String key = entry.getKey();
                        String value = entry.getValue();
                        alldump.put(key, value);
                    }
                    Log.v(queryString,"2");

                    for (int i=0;i<allAlivePorts.size();i++) {
                        String pi = getPortFromEmulator(getEmulatorFromHash(allAlivePorts.get(i)));
                        getLocalDumpFrom.put(pi,Boolean.FALSE);
                    }
                    Log.v(queryString,"3");

                    for (int i=0;i<allAlivePorts.size();i++){
                        Log.v(queryString,"4");
                        String pi = getPortFromEmulator(getEmulatorFromHash(allAlivePorts.get(i)));
                        if (!pi.equals(myPortGlobal)) {
                            Log.v(queryString,"5");
                            Boolean valReq = Boolean.FALSE;
                            while (getLocalDumpFrom.containsKey(pi) && !getLocalDumpFrom.get(pi)) {
                                //Log.v(queryString,"8");
                                if (!valReq) {
                                    Log.v(queryString,"9");
                                    Node n2 = new Node((selection), "", "giveLocalDump", "", isBaseNodeOperable, "", myPortGlobal);
                                    Thread t1 = getClientThread(n2, pi);
                                    t1.start();
                                }
                                valReq = Boolean.TRUE;
                            }
                        }
                    }
                } catch (NoSuchAlgorithmException e) {

                }

                Log.v(queryString,"dumping all");
                //getting all the dump to the cursor set
                for (Map.Entry<String, String> entry : alldump.entrySet()) {
                        String key = entry.getKey();
                        String value = entry.getValue();
                        cursorz.addRow(new String[]{key, value});
                }
            }
            return cursorz;
            }
        else {
            try {
                Log.v(queryString, " KEY is: " + selection + " FOUND VALUE: " + foundValue + " VALUE RET: " + valueReturnQ + " ORIGINQ" + queryOrigin  + " MY PORT: " + myPortGlobal);
                String key = selection;
                if (!localAllMsg.containsKey(selection)) {
                    Log.v(queryString,"KEY IS: "+selection + "From : 1");
                    Boolean valuRequested = Boolean.FALSE;
                    Log.v(queryString,"KEY IS: "+selection + "From : 2");
                    while (valueReturnQ.equals("")) {
                        //Log.v(queryString,"KEY IS: "+selection + "From : 3");
                        if (!valuRequested) {
                            Log.v(queryString, "Key is:" + selection + "In Port: " + myPortGlobal + " frwd to succ:" + getEmulatorFromHash(p1.getSuccessor()));
                            Log.v(queryString, " Key: " + selection + "QUERY ORIGIN" + queryOrigin);
                            if (queryOrigin.equals("")) {
                                queryOrigin = getPortFromEmulator(getEmulatorFromHash(p1.getPortNumber()));
                            }
                            Node n1 = new Node((selection), "", "query", "", isBaseNodeOperable, "", queryOrigin);
                            Thread t1 = getClientThread(n1, getPortFromEmulator(getEmulatorFromHash(p1.getSuccessor())));
                            t1.start();
                        }else{
                            //Log.v(queryString,"KEY IS: "+selection + "From : 4");
                            if (!queryOrigin.equals(myPortGlobal)){
                                Log.v(queryString,"KEY IS: "+selection + "From : 5");
                                break;
                            }
                        }
                        valuRequested = Boolean.TRUE;
                    }
                }
                if (localAllMsg.containsKey(selection)) {
                    if (queryOrigin.equals("")){
                        queryOrigin = myPortGlobal;
                    }
                    Log.v(queryString,"KEY IS: "+selection + "From : 6");
                    if (queryOrigin.equals(myPortGlobal)) {
                        Log.v(queryString,"KEY IS: "+selection + "From : 7");
                        valueReturnQ = localAllMsg.get(selection);
                    }
                    if (!queryOrigin.equals(myPortGlobal)) {
                        Log.v(queryString,"KEY IS: "+selection + "From : 8");
                        Node n2 = new Node((selection), localAllMsg.get(selection), "returnQuery", "", isBaseNodeOperable, localAllMsg.get(selection), queryOrigin);
                        Thread t2 = getClientThread(n2, queryOrigin);
                        t2.start();
                    }
                }
                Log.v(queryString,"FINAL QUERY ORIGIN: "+queryOrigin+" VALUE RETURN Q:"+valueReturnQ);
                cursorz.addRow(new String[]{selection, valueReturnQ});
                queryOrigin = "";
                valueReturnQ = "";

                } catch(NoSuchAlgorithmException e){
                    Log.v("Querying Data", "No Such Algo");
                } catch(Exception e){
                    e.printStackTrace();
                    Log.v("QUerying data", "Q");
                    cursorz.addRow(new String[]{selection, "N/A"});
                }
            }
        return cursorz;
    }

    @Override
    public int update(Uri uri, ContentValues values, String selection, String[] selectionArgs) {
        // TODO Auto-generated method stub
        return 0;
    }

    private String genHash(String input) throws NoSuchAlgorithmException {
        MessageDigest sha1 = MessageDigest.getInstance("SHA-1");
        byte[] sha1Hash = sha1.digest(input.getBytes());
        Formatter formatter = new Formatter();
        for (byte b : sha1Hash) {
            formatter.format("%02x", b);
        }
        return formatter.toString();
    }

    private Uri buildUri(String scheme, String authority) {
        Uri.Builder uriBuilder = new Uri.Builder();
        uriBuilder.authority(authority);
        uriBuilder.scheme(scheme);
        return uriBuilder.build();
    }

    //Create Client Thread
    //Send the Node msg and The destination port in String
    //Thread t1 = getClientThread(msg,port);
    //t1.start();

    public class CreateServerSocket {
        ServerSocket s;

        CreateServerSocket(ServerSocket s) {
            Log.v(ServerThread,"CreateServerSocket");
            this.s = s;
        }

        public void serversocketaccept() {
        }
    }

    public class CreateServerSocketRunnable implements Runnable{
        ServerSocket s1;

        CreateServerSocketRunnable(ServerSocket s2){
            Log.v(ServerThread,"In CreateServerSocketRunnable");
            this.s1 = s2;
        }

        public void run(){

            synchronized (s1) {
                //Log.v(ServerThread, "yes");
                Node inputte = null;
                String ainput;

                try {
                    //Log.v(ServerThread, "In Try");
                    while (true) {
                        ServerSocket serverSocket = s1;
                        //Log.v(ServerThread, "in while true");
                        Socket socket = serverSocket.accept();
                        //Log.v(ServerThread, "Got socket");
                        ObjectInputStream ois = new ObjectInputStream(socket.getInputStream());
                        //Log.v(ServerThread, "Read input stream");
                        ainput = (String) ois.readObject();
                        //Log.v(ServerThread,ainput);
                        String[] inputarr = ainput.split(";");
                        Log.v(ServerThread, "AINPUT:"+ainput+"Length od inputarr"+inputarr.length);
                        //msg.getKey()+";"+msg.getValue()+";"+msg.getAction()+";"+msg.getQueryValue()+";"+msg.getStartNode()+";"+msg.getJoinNode());

                        String keyx = "";
                        String valuex = "";
                        String actionx = "";
                        String joinNodex = "";
                        String queryValue = "";
                        String startNodeForQuery = "";
                        if (inputarr.length == 3){
                            if (inputarr[0]!=null) {
                                keyx = (inputarr[0]);
                            }
                            if (inputarr[1]!=null) {
                                valuex = (inputarr[1]);
                            }
                            if (inputarr[2]!=null) {
                                actionx = (inputarr[2]);
                            }
                        }
                        if (inputarr.length == 4){
                            if (inputarr[0]!=null) {
                                keyx = (inputarr[0]);
                            }
                            if (inputarr[1]!=null) {
                                valuex = (inputarr[1]);
                            }
                            if (inputarr[2]!=null) {
                                actionx = (inputarr[2]);
                            }
                            if (inputarr[3]!=null){
                                queryValue = inputarr[3];
                            }
                        }
                        if (inputarr.length==5) {
                            if (inputarr[0]!=null) {
                                keyx = (inputarr[0]);
                            }
                            if (inputarr[1]!=null) {
                                valuex = (inputarr[1]);
                            }
                            if (inputarr[2]!=null) {
                                actionx = (inputarr[2]);
                            }
                            if (inputarr[3]!=null){
                                queryValue = inputarr[3];
                            }
                            if (inputarr[4]!=null){
                                startNodeForQuery = inputarr[4];
                            }
                        }
                        if (inputarr.length==6){
                            if (inputarr[0]!=null) {
                                keyx = (inputarr[0]);
                            }
                            if (inputarr[1]!=null) {
                                valuex = (inputarr[1]);
                            }
                            if (inputarr[2]!=null) {
                                actionx = (inputarr[2]);
                            }
                            if (inputarr[3]!=null){
                                queryValue = inputarr[3];
                            }
                            if (inputarr[4]!=null){
                                startNodeForQuery = inputarr[4];
                            }
                            if (inputarr[5]!=null) {
                                joinNodex = inputarr[5];
                            }
                        }
                        //Log.v(ServerThread,"Key used"+keyx);
                        //Log.v(ServerThread,"Value is:"+valuex);
                        inputte = new Node(keyx, valuex, actionx,joinNodex, isBaseNodeOperable,queryValue,startNodeForQuery);
                        if (inputte == null) {
                            Log.v(ServerThread,"Inputte is null");
                            break;
                        }
                        Log.v(ServerThread, "The action is: " + inputte.getAction());
                        if(inputte.getAction().equals("add5554")){
                            isBaseNodeOperable = Boolean.TRUE;
                        }
                        if (inputte.getAction().equals("join")) {
                            Log.v(ServerThread, "Join");
                                try {
                                    if (!allAlivePorts.contains((inputte.getJoinNode()))) {
                                        addInSortedOrder((inputte.getJoinNode()));
                                    }
                                    if (!portList.containsKey((inputte.getJoinNode()))) {
                                        addAndUpdateNodeToPortsList((inputte.getJoinNode()));
                                    }
                                    sentOutUpdates(inputte.getJoinNode());
                                } catch (NoSuchAlgorithmException e) {
                                    Log.v(ServerThread, "Problem with Hashing");
                                } catch (Exception e) {
                                    Log.v(ServerThread, "Join");
                                }
                        }
                        if (inputte.getAction().equals("update")) {
                            //Log.v(ServerThread, "Update");
                            try {
                                String[] h = inputte.getJoinNode().split("@");
                                int len = h.length;
                                for (int i=0;i<len;i++) {
                                    //Log.v(ServerThread,"Update with node: "+getPortFromHash(h[i])+" and Hash: "+h[i]);
                                    if (!allAlivePorts.contains(h[i])) {
                                        addInSortedOrder(h[i]);
                                    }
                                    if (!portList.containsKey(h[i])) {
                                        addAndUpdateNodeToPortsList(h[i]);
                                    }
                                }
                            } catch (Exception e) {
                                Log.v(ServerThread, "Update");
                            }
                        }
                        if (inputte.getAction().equals("insert")) {
                            Log.v(ServerThread, "Insert");
                            String key = inputte.getKey();
                            String val = inputte.getValue();
                            ContentValues cv = new ContentValues();
                            cv.put(KEY_FIELD, key);
                            cv.put(VALUE_FIELD, val);
                            insert(mUri, cv);
                        }
                        if (inputte.getAction().equals("QueryAll")) {
                            query(mUri, null, "@", null, null);
                        }
                        if (inputte.getAction().equals("query")) {
                            queryOrigin = startNodeForQuery;
                            query(mUri, null, keyx, null, null);
                        }
                        if (inputte.getAction().equals("returnQuery")){
                            queryOrigin = startNodeForQuery;
                            valueReturnQ = queryValue;
                            foundValue = Boolean.TRUE;
                            //query(mUri, null, keyx, null, null);
                            //sentOutUpdatesToQueryOrigin(keyx);
                        }
                        if (inputte.getAction().equals("PutQueryOriginForKey")){
                            queryOrigin = "";
                            valueReturnQ = "";
                            foundValue = Boolean.FALSE;
                        }
                        if (inputte.getAction().equals("giveLocalDump")){
                            Log.v(ServerThread,"10");
                            queryOrigin = startNodeForQuery;
                            String localDumpMap = givelocalmapdump();
                            Node nn = new Node("", "", "takeLocalDump", localDumpMap, isBaseNodeOperable, "", myPortGlobal);
                            Thread t4 = getClientThread(nn, queryOrigin);
                            t4.start();
                        }
                        if (inputte.getAction().equals("takeLocalDump")){
                            Log.v(ServerThread,"11");
                            String gotFromQuery = startNodeForQuery;
                            Log.v(ServerThread,"This query Dump: "+gotFromQuery + "Join Node" + inputte.getJoinNode());
                            if (!inputte.getJoinNode().equals("")) {
                                ConcurrentHashMap<String, String> newLocalDump = getlocalmapdump(inputte.getJoinNode());
                                for (Map.Entry<String, String> entry : newLocalDump.entrySet()) {
                                    String key = entry.getKey();
                                    String value = entry.getValue();
                                    alldump.put(key, value);
                                }
                            }
                            getLocalDumpFrom.put(gotFromQuery,Boolean.TRUE);
                        }
                        if (inputte.getAction().equals("deletequery")){
                            delete(mUri, keyx,null);
                            //localAllMsg.remove(keyx);
                        }
                        try {
                            Log.v(ServerThread, "Ends here");
                        } catch (Exception e) {
                            e.printStackTrace();
                            Log.e(TAG, "File write failed");
                        }
                        ois.close();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    Log.e(TAG, "File write failed");
                }
            }
        }
    }

    public class CLientScoketCreateRunnable implements Runnable{

        String msg;
        String port;
        CLientSocketCreate socket1 ;

        CLientScoketCreateRunnable(CLientSocketCreate socket){
            //Log.v("CLientScoketCreateRunn","In here");
            this.socket1 = socket;
        }

        public void run() {
            //Log.v("CLientScoketCreateRunn","In here trying to run the CLientSocketCreate send data");
            socket1.sendData();
        }
    }

    public class CLientSocketCreate {
        Node msg;
        String port;
        Socket s ;

        CLientSocketCreate(Node message, String ports) {
            msg = message;
            port = ports;
        }

        public void sendData() {
            //synchronized (test) {
                try {
                    Log.v("Send data", msg.printSendNode() + "PORT: " + port);
                    if (port != null) {
                        s = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}), Integer.parseInt(port));
                        ObjectOutputStream oos1 = new ObjectOutputStream(s.getOutputStream());
                        //Log.v("msgToSendInsideSync", msg.getNodeReadyToSend());
                        oos1.writeObject(msg.getKey()+";"+msg.getValue()+";"+msg.getAction()+";"+msg.getQueryValue()+";"+msg.getStartNode()+";"+msg.getJoinNode());
                        oos1.close();
                        s.close();
                    }
                } catch (ConnectException e){
                    isBaseNodeOperable = Boolean.FALSE;
                    Log.e("sendData Catch", "IO");
                }
                catch (IOException e) {
                    e.printStackTrace();
                }
            //}
        }
    }
    public class Port{
        int numberInCircle;
        String portNumber;
        String predecessor;
        String successor;
        ArrayList<String> hit = new ArrayList<String>();
        ArrayList<String> hitQ = new ArrayList<String>();
        ArrayList<String> queried = new ArrayList<String>();

        Port(String predecessor, String portNumber,String successor){
            this.portNumber = portNumber;
            this.predecessor = predecessor;
            this.successor = successor;
        }

        public ArrayList<String> getHitQ() {
            return hitQ;
        }

        public void setHitQ(ArrayList<String> hitQ) {
            this.hitQ = hitQ;
        }

        public void setPortNumber(String portNumber) {
            this.portNumber = portNumber;
        }

        public ArrayList<String> getQueried() {
            return queried;
        }

        public void setQueried(ArrayList<String> queried) {
            this.queried = queried;
        }

        public void setPredecessor(String predecessor) {
            this.predecessor = predecessor;
        }

        public void setSuccessor(String successor) {
            this.successor = successor;
        }

        public ArrayList<String> getHit() {
            return hit;
        }

        public int getNumberInCircle() {
            return numberInCircle;
        }

        public void setNumberInCircle(int numberInCircle) {
            this.numberInCircle = numberInCircle;
        }

        public void setHit(ArrayList<String> hit) {
            this.hit = hit;
        }

        /*public void setHit(int isHit){
            this.hit = isHit;
        }
        public int getHit(){
            return this.hit;
        }*/

        public String getPortNumber(){
            return this.portNumber;
        }

        public String getPredecessor(){
            return this.predecessor;
        }

        public String getSuccessor(){
            return this.successor;
        }

        public String printData(){
            return "Port Number: "+this.portNumber+" Pred: "+ this.predecessor + "SUCC: "+ this.successor;
        }

        public String printDataRead(){
            try {
                String a =  "Port Number: " + getPortFromEmulator(getEmulatorFromHash(this.portNumber))
                        + " Pred: " + getPortFromEmulator(getEmulatorFromHash(this.predecessor))
                        + "SUCC: " + getPortFromEmulator(getEmulatorFromHash(this.successor))
                        + "Number In Circle"+(this.numberInCircle);
                return a;
            }catch (NoSuchAlgorithmException e){
                Log.v("No Such Hash","Algo");
                return "";
            }
        }
    }

    public class Node{
        //private static final long serialVersionUID = 6128016096756071380L;
        String key = "";
        String value = "";
        String action = "";
        String joinNode = "";
        Boolean isAliveBase = Boolean.FALSE;
        String queryValue = "";
        String startNode = "";

        public Node(String key, String value, String action,String joinNode,Boolean isAliveBase, String queryValue, String startNode){
            this.key = key;
            this.value = value;
            this.action = action;
            this.joinNode = joinNode;
            this.isAliveBase = isAliveBase;
            this.queryValue = queryValue;
            this.startNode = startNode;
        }

        public String getNodeReadyToSend(){
            String msgToPrint = this.key+";"+this.value+";"+this.action+";"+this.joinNode;
            return  msgToPrint  ;
        }

        public String printSendNode(){
            String msgToPrint = "Key:"+this.key+";"+"Value:"+this.value+";"+"Action:"+ this.action+";"+"NodeJoin:"+this.joinNode;
            return  msgToPrint  ;
            //allAlivePort+circularNode;
        }

        public String getKey(){
            return this.key;
        }

        public String getValue(){
            return this.value;
        }

        public String getAction(){
            return this.action;
        }

        public String getJoinNode(){
            return this.joinNode;
        }

        public String getQueryValue() {
            return queryValue;
        }

        public void setQueryValue(String queryValue) {
            this.queryValue = queryValue;
        }

        public String getStartNode() {
            return startNode;
        }

        public void setStartNode(String startNode) {
            this.startNode = startNode;
        }

        public void setKey(String key){
            this.key = key;
        }

        public void setValue(String value) {
            this.value = value;
        }

        public void setAction(String action) {
            this.action = action;
        }

        public void setJoinNode(String joinNode) {
            this.joinNode = joinNode;
        }
    }

    public Thread getServerThread(ServerSocket serverSocket){
        Log.v(ServerThread,"getServerThread with a server socket");
        //CreateServerSocket s1 = new CreateServerSocket(serverSocket);
        CreateServerSocketRunnable sr1 = new CreateServerSocketRunnable(serverSocket);
        Thread t2 = new Thread(sr1);
        return t2;
    }

    public Thread getClientThread(Node msg,String port){
        try {
            Log.v(ClientThread, "getClientThread: " + msg.printSendNode() + "With Port: " + (port));
        }catch (Exception e){
            Log.v("No SUCh algo","Cl");
        }
        CLientScoketCreateRunnable scc4 = new CLientScoketCreateRunnable(new CLientSocketCreate(msg, port));
        Thread t1 = new Thread(scc4);
        return t1;
    }

    public void addAndUpdateNodeToPortsList(String a1){
        synchronized (portList) {
            try {
                String a = portToEmulator(getPortFromHashForSingle(a1));
                if(!portList.containsKey(a)){
                    Port px = getPortwithSuccAndPred(a);
                    portList.put(a, px);
                }
                Map<String, Port> map = portList;
                for (Map.Entry<String, Port> entry : map.entrySet()) {
                    int flag = 0;
                    String key = entry.getKey();
                    Port p1 = entry.getValue();
                    if (allAlivePorts.size()!=0){
                        if (p1.getPredecessor()==p1.getPortNumber() || p1.getSuccessor()==p1.getPortNumber()){
                            //Log.v(addAndUpdateNodeToPortsListString,"Key is"+getEmulatorFromHash(key)+" Port is"+p1.printDataRead());
                            Port py = getPortwithSuccAndPred(key);
                            String pred1 = py.getPredecessor();
                            String succ2 = py.getSuccessor();
                            int number = py.getNumberInCircle();
                            if (!p1.getSuccessor().equals(succ2)){
                                p1.setSuccessor(succ2);
                                flag = 1;
                            }
                            if (!p1.getPredecessor().equals(pred1)){
                                p1.setPredecessor(pred1);
                                flag =1;
                            }
                            /*if (p1.getNumberInCircle()!= number){
                                p1.setNumberInCircle(number);
                                flag = 1;
                            }*/
                            if (flag==1) {
                                //Log.v(addAndUpdateNodeToPortsListString,"Trying to update Map");
                                //Log.v(addAndUpdateNodeToPortsListString,p1.printDataRead());
                                portList.put(key,p1);
                            }
                        }
                    }

                }
                Map<String, Port> map1 = portList;
                for (Map.Entry<String, Port> entry : map1.entrySet()) {
                    String key = entry.getKey();
                    Port p1 = entry.getValue();
                    //Log.v(addAndUpdateNodeToPortsListString,"BEFORE"+p1.printDataRead());
                    if (allAlivePorts.size()==1) {
                        if (allAlivePorts.get(0).equals(p1.getPortNumber())) {
                            p1.setNumberInCircle(0);
                        }
                    }else if (allAlivePorts.size()==2){
                        //Log.v(addAndUpdateNodeToPortsListString,printConcurrentList());
                        if (allAlivePorts.get(0).equals(p1.getPortNumber())) {
                            //Log.v(addAndUpdateNodeToPortsListString,"PORT NUM: "+getEmulatorFromHash(p1.getPortNumber())+"ALLLIST AT: "+getEmulatorFromHash(allAlivePorts.get(0)));
                            p1.setNumberInCircle(0);
                        }else if (allAlivePorts.get(1).equals(p1.getPortNumber())){
                            //Log.v(addAndUpdateNodeToPortsListString,"PORT NUM: "+getEmulatorFromHash(p1.getPortNumber())+"ALLLIST AT: "+getEmulatorFromHash(allAlivePorts.get(1)));
                            p1.setNumberInCircle(1);
                        }
                    }else if (allAlivePorts.size()==3){
                        if (allAlivePorts.get(0).equals(p1.getPortNumber())) {
                            p1.setNumberInCircle(0);
                        }else if (allAlivePorts.get(1).equals(p1.getPortNumber())){
                            p1.setNumberInCircle(1);
                        }else if (allAlivePorts.get(2).equals(p1.getPortNumber())){
                            p1.setNumberInCircle(2);
                        }
                    }else if (allAlivePorts.size()==4) {
                        if (allAlivePorts.get(0).equals(p1.getPortNumber())) {
                            p1.setNumberInCircle(0);
                        } else if (allAlivePorts.get(1).equals(p1.getPortNumber())) {
                            p1.setNumberInCircle(1);
                        } else if (allAlivePorts.get(2).equals(p1.getPortNumber())) {
                            p1.setNumberInCircle(2);
                        }else if (allAlivePorts.get(3).equals(p1.getPortNumber())) {
                            p1.setNumberInCircle(3);
                        }
                    }else if (allAlivePorts.size()==5) {
                        if (allAlivePorts.get(0).equals(p1.getPortNumber())) {
                            p1.setNumberInCircle(0);
                        } else if (allAlivePorts.get(1).equals(p1.getPortNumber())) {
                            p1.setNumberInCircle(1);
                        } else if (allAlivePorts.get(2).equals(p1.getPortNumber())) {
                            p1.setNumberInCircle(2);
                        }else if (allAlivePorts.get(3).equals(p1.getPortNumber())) {
                            p1.setNumberInCircle(3);
                        }else if (allAlivePorts.get(4).equals(p1.getPortNumber())) {
                            p1.setNumberInCircle(4);
                        }
                    }
                    //Log.v(addAndUpdateNodeToPortsListString,"AFTER"+p1.printDataRead());
                    portList.put(key,p1);
                }

                //Log.v(addAndUpdateNodeToPortsListString, "PORT: "+ getEmulatorFromHash(a)+" " + "NUMBER OF KEYS" + (getKeysFromHashMap()));
                //Log.v(addAndUpdateNodeToPortsListString, "PORT: "+ getEmulatorFromHash(a)+" " + "MAP" + printConcurrentHashMap());
                        //"AFTER MAP: " + printConcurrentHashMap());
            }catch (NoSuchAlgorithmException e){
                Log.v(addAndUpdateNodeToPortsListString,"No such Algo");
            }
        }
    }

    public Port getPortwithSuccAndPred(String a){
        Port p1 = new Port("", a, "");
        String pred = "";
        String succ = "";
        //int n0 = -1;
        try {
            int predclose = 10000;
            int succclose = 10000;
            String predcloses = "";
            String succcloses = "";
            if (allAlivePorts.size() == 0) {
                pred = "0";
                succ = "0";
            } else if (allAlivePorts.size() == 1) {
                pred = a;
                succ = a;
                //n0 = 0;
            } else if (allAlivePorts.size() == 2) {
                for (String s : allAlivePorts) {
                    if (!s.equals(a)) {
                        pred = s;
                        succ = s;
                    }
                }
                //if (allAlivePorts.get(0).equals(a)){
                    //n0 = 0;
                //}else if (allAlivePorts.get(1).equals(a)){
                    //n0 = 1;
                //}
            } else {
                for (String s : allAlivePorts) {
                    if (!s.equals(a)) {
                        int diff = (a.compareTo(s));
                        //Log.v(getPredForNodeString, "PORT"+getEmulatorFromHash(a)+" DIFF From" + getEmulatorFromHash(s) + "is:" + Integer.toString(diff));
                        //if diff > 0, s is capable of being a's succ
                        if (diff > 0) {
                            if (diff < predclose) {
                                predclose = diff;
                                predcloses = s;
                                succcloses = "";
                            }
                        }
                        else if (diff < 0) {
                            diff = Math.abs(diff);
                            if (diff < succclose) {
                                succclose = diff;
                                succcloses = s;
                                predcloses = "";
                            }
                        }
                    }
                }
                /*for (int i =0 ;i<allAlivePorts.size();i++){
                    if (allAlivePorts.get(i).equals(a)){
                        n0 = i;
                    }
                }*/
                if (predcloses!=""){
                    Port f1 = portList.get(predcloses);
                    if (succcloses==""){
                        succcloses = f1.getSuccessor();
                        Port ps = portList.get(succcloses);
                        ps.setPredecessor(a);
                        portList.put(succcloses,ps);
                    }
                    f1.setSuccessor(a);
                    //portList.remove(predcloses);
                    portList.put(predcloses,f1);
                }
                if (succcloses!=""){
                    //set the success pred to this port a
                    Port f2 = portList.get(succcloses);
                    if (predcloses==""){
                        //We did not find pred
                        predcloses = f2.getPredecessor();
                        Port pp = portList.get(predcloses);
                        pp.setSuccessor(a);
                        portList.put(predcloses,pp);
                    }
                    f2.setPredecessor(a);
                    //portList.remove(a);
                    portList.put(succcloses,f2);
                }
                //Log.v(getPredForNodeString,"PREDECESSOR for port: "+getEmulatorFromHash(a)+" is:"+getEmulatorFromHash(predcloses));
                //Log.v(getPredForNodeString,"SUCCESSOR for port: "+getEmulatorFromHash(a)+" is:"+ getEmulatorFromHash(succcloses));
                pred = predcloses;
                succ = succcloses;
            }
        }catch (Exception e){

        }
        p1.setPredecessor(pred);
        p1.setSuccessor(succ);
        //p1.setNumberInCircle(n0);
        return p1;
    }

    public void addInSortedOrder(String a1){
        synchronized (allAlivePorts) {
            try {
                String a = portToEmulator(getPortFromHashForSingle(a1));
                //Log.v(addInSortedOrderString, "PORT: "+ getPortFromHashForSingle(a) + " BEFORE LIST: "+printConcurrentList());
                if (!allAlivePorts.contains(a)) {
                    allAlivePorts.add(a);
                    Collections.sort(allAlivePorts);
                    Log.v(addInSortedOrderString, "PORT: "+ getEmulatorFromHash(a)+" AFTER LIST: "+printConcurrentList());
                }
            }catch (NoSuchAlgorithmException e){
                Log.v(addInSortedOrderString,"No such Algo");
            }

        }
    }

    public String printLocalALlMsg() {
        //synchronized (portList) {
        String S = "";
        try {
            Map<String, String> map = localAllMsg;
            for (Map.Entry<String, String> entry : map.entrySet()) {
                String key = entry.getKey().toString();
                String p1 = entry.getValue();
                S = S + "key: " + (key) + " value: " + p1 + "     ";
            }
            //Log.v("Map is", S);

        }catch (Exception e){
            Log.v("NO SUHC","PRINT CONCURRENT");
        }return S;
        //}return S;
    }

    public int getKeysFromHashMap() {
        //synchronized (portList) {
        int c = 0;
        try {
            Map<String, Port> map = portList;
            for (Map.Entry<String, Port> entry : map.entrySet()) {
                String key = entry.getKey().toString();
                c = c+1;
            }
        }catch (Exception e){
            Log.v("NO SUHC","PRINT CONCURRENT");
        }
        return c;
        //}return S;
    }

    public String printConcurrentHashMap() {
        //synchronized (portList) {
            String S = "";
            try {
                Map<String, Port> map = portList;
                for (Map.Entry<String, Port> entry : map.entrySet()) {
                    String key = entry.getKey().toString();
                    Port p1 = entry.getValue();
                    S = S + "key: " + getEmulatorFromHash(key) + " value: " + p1.printDataRead() + "     ";
                }
                //Log.v("Map is", S);

            }catch (NoSuchAlgorithmException e){
                Log.v("NO SUHC","PRINT CONCURRENT");
            }return S;
        //}return S;
    }

    public String printConcurrentList() throws  NoSuchAlgorithmException{
        synchronized (allAlivePorts) {
            String V = "";
            if (allAlivePorts.size() ==0){
                V = "Empty";
            }
            if (allAlivePorts.size() != 0) {
                for (String s : allAlivePorts) {
                    V = V + "  " + getEmulatorFromHash(s);
                }
                //Log.v("List is", V);
            }
            return V;
        }
    }

    public void sentOutUpdates(String nodeJoin) throws NoSuchAlgorithmException{
        String a = "";
        for (String s:allAlivePorts){
            a = a + genHash(getPortFromEmulator(getEmulatorFromHash(s))) +"@";
        }
        //Log.v("sentOutUpdates",a);
        a = a.substring(0,a.lastIndexOf('@'));
        //Log.v("sentOutUpdates",a);
        Node n1 = new Node("", "", "update",a,isBaseNodeOperable,"","");
        for (int i=0;i<allAlivePorts.size();i++){
            String port = getPortFromEmulator(getEmulatorFromHash(allAlivePorts.get(i)));
            Thread t1 = getClientThread(n1,port);
            t1.start();
        }
    }

    public void sentOutUpdatesToQueryOrigin(String key)throws NoSuchAlgorithmException{
        String a = "";
        for (String s:allAlivePorts){
            a = a + genHash(getPortFromEmulator(getEmulatorFromHash(s))) +"@";
        }
        //Log.v("sentOutUpdates",a);
        a = a.substring(0,a.lastIndexOf('@'));
        //Log.v("sentOutUpdates",a);
        Node n1 = new Node("", "", "PutQueryOriginForKey",a,isBaseNodeOperable,"","");
        for (int i=0;i<allAlivePorts.size();i++){
            String port = getPortFromEmulator(getEmulatorFromHash(allAlivePorts.get(i)));
            if (port!=myPortGlobal) {
                Thread t1 = getClientThread(n1, port);
                t1.start();
            }
        }
    }

    public String getPortFromHash (String a) throws NoSuchAlgorithmException {
        String result = "";
        if (a==""){
            result = "just Starting";
        }
        if(a!="") {
            String[] strSplit = a.split(";");
            for (int i = 0; i < strSplit.length; i++) {
                String b = strSplit[i];
                //Log.v("getPortFromHash", "Gen Hash: " + b);
                result = result + ":" + getPortFromHashForSingle(b);

            }
            //Log.v("getPortFromHash", "PortNumber: " + result);
        }
        return result;
    }

    public String getPortFromHashForSingle (String a) throws NoSuchAlgorithmException {
            String result = "";
            String h0 = genHash(REMOTE_PORT0);
            String h1 = genHash(REMOTE_PORT1);
            String h2 = genHash(REMOTE_PORT2);
            String h3 = genHash(REMOTE_PORT3);
            String h4 = genHash(REMOTE_PORT4);
            if (a.equals(h0)) {
                result = REMOTE_PORT0;
            }
            if (a.equals(h1)) {
                result = REMOTE_PORT1;
            }
            if (a.equals(h2)) {
                result = REMOTE_PORT2;
            }
            if (a.equals(h3)) {
                result = REMOTE_PORT3;
            }
            if (a.equals(h4)) {
                result = REMOTE_PORT4;
            }
        //Log.v("getPortFromHash", "PortNumber: " + result);
        return result;
    }

    public String portToEmulator(String a) throws NoSuchAlgorithmException{
        String result = "";
        String h0 = genHash(R_0);
        String h1 = genHash(R_1);
        String h2 = genHash(R_2);
        String h3 = genHash(R_3);
        String h4 = genHash(R_4);
        if (a.equals(REMOTE_PORT0)) {
            result = h0;
        }
        if (a.equals(REMOTE_PORT1)) {
            result = h1;
        }
        if (a.equals(REMOTE_PORT2)) {
            result = h2;
        }
        if (a.equals(REMOTE_PORT3)) {
            result = h3;
        }
        if (a.equals(REMOTE_PORT4)) {
            result = h4;
        }
        return result;
    }

    public String getEmulatorFromHash(String a) throws NoSuchAlgorithmException{
        String result = "";
        String h0 = genHash(R_0);
        String h1 = genHash(R_1);
        String h2 = genHash(R_2);
        String h3 = genHash(R_3);
        String h4 = genHash(R_4);
        if (a.equals(h0)) {
            result = R_0;
        }
        if (a.equals(h1)) {
            result = R_1;
        }
        if (a.equals(h2)) {
            result = R_2;
        }
        if (a.equals(h3)) {
            result = R_3;
        }
        if (a.equals(h4)) {
            result = R_4;
        }
        //Log.v("getPortFromHash", "PortNumber: " + result);
        return result;
    }

    public void sendToRemotePort0(Node n1){
        Thread t1 = getClientThread(n1, REMOTE_PORT0);
        t1.start();
        try {
            Log.v("Try to add",REMOTE_PORT0);
            if (!allAlivePorts.contains(genHash(REMOTE_PORT0))) {
                addInSortedOrder(genHash(REMOTE_PORT0));
            }
            if (!portList.containsKey(genHash(REMOTE_PORT0))) {
                addAndUpdateNodeToPortsList(genHash(REMOTE_PORT0));
            }
        } catch (NoSuchAlgorithmException e) {
            Log.v(ServerThread, "Problem with Hashing");
        } catch (Exception e) {
            Log.v(ServerThread, "Join");
        }
    }

    public int getLocationToUse(Port p1,String key, String use)throws  NoSuchAlgorithmException {
        int loc = 0;
        use = use + " Key: " + key;

        Boolean sendToSucc = Boolean.FALSE;
        Boolean insertInYouself = Boolean.FALSE;
        Boolean sendTopred = Boolean.FALSE;

        Boolean isSuccessorSameAsPort = Boolean.FALSE;
        Boolean isPredecessorSameAsPort = Boolean.FALSE;

        //Log.v(use,  " IS SUCCESSOR SAME AS PORT: " + Boolean.toString(isSuccessorSameAsPort));
        if (p1.getSuccessor().equals(genHash(myPortStr))) {
            isSuccessorSameAsPort = Boolean.TRUE;
        }

        if (p1.getPredecessor().equals(genHash(myPortStr))) {
            isPredecessorSameAsPort = Boolean.TRUE;
        }


        Boolean hasPortBeenVisited = Boolean.FALSE;
        int diffMinePred = (genHash(myPortStr)).compareTo(p1.getPredecessor());
        int diffMineSucc = (genHash(myPortStr)).compareTo(p1.getSuccessor());
        Boolean hasSuccessorPortBeenVisited = Boolean.FALSE;
        Boolean hasPredecessorPortBeenVisited = Boolean.FALSE;


        if (p1.getHit() == null) {
            hasPortBeenVisited = Boolean.FALSE;
        } else if (p1.getHit() != null && p1.getHit().contains(key)) {
            hasPortBeenVisited = Boolean.TRUE;
        }

        Port ps = portList.get(p1.getSuccessor());
        if (ps.getHit() == null) {
            hasSuccessorPortBeenVisited = Boolean.FALSE;
        } else if (ps.getHit() != null && ps.getHit().contains(key)) {
            hasSuccessorPortBeenVisited = Boolean.TRUE;
        }

        Port pp = portList.get(p1.getPredecessor());
        if (pp.getHit() == null) {
            hasPredecessorPortBeenVisited = Boolean.FALSE;
        } else if (pp.getHit() != null && pp.getHit().contains(key)) {
            hasPredecessorPortBeenVisited = Boolean.TRUE;
        }

        if (allAlivePorts.size() == 1) {
            if (isPredecessorSameAsPort || isSuccessorSameAsPort) {
                //Log.v(use, "Key : " + key + "Setting Insert in Yourself True From here 1");
                insertInYouself = Boolean.TRUE;
            }
        }else if (allAlivePorts.size() >= 2) {

            String kh = genHash(key);
            String mh = (p1.getPortNumber());
            String ph = p1.getPredecessor();

            //this is the first node
            if (ph.compareTo(mh)>0 && kh.compareTo(ph) >0 && kh.compareTo(mh)>0 ){
                    Log.v(use,"Set insert in yourself here 1");
                    insertInYouself = Boolean.TRUE;
            }
            if (ph.compareTo(mh)>0 && kh.compareTo(ph)<0 && kh.compareTo(mh) <=0){
                    Log.v(use,"Set insert in yourself here 2");
                    insertInYouself = Boolean.TRUE;
            }
            //for all other nodes
            if (kh.compareTo(ph)>0 && kh.compareTo(mh) <=0){
                Log.v(use,"Set insert in yourself here 3");
                insertInYouself = Boolean.TRUE;
            }
        }

        if (insertInYouself){
            sendToSucc = Boolean.FALSE;
        } else if (!insertInYouself){
            sendToSucc = Boolean.TRUE;
        }


        if (sendToSucc) {
            Log.v(use, "Key " + key + " Send to Successor" + Boolean.toString(sendToSucc));
            loc = 1;
        }
        if (insertInYouself) {
            Log.v(use, "Key " + key + " Insert In Yourself" + Boolean.toString(insertInYouself));
            loc = 3;
        }
        if (sendTopred) {
            Log.v(use, "Key " + key + " Send to Predecessor" + Boolean.toString(sendTopred));
            loc = 2;
        }
        return loc;
    }

    private String getPortFromEmulator(String a){
        String result = "";
        if (a.equals(R_0)){
            result = REMOTE_PORT0;
        }
        if (a.equals(R_1)){
            result = REMOTE_PORT1;
        }
        if (a.equals(R_2)){
            result = REMOTE_PORT2;
        }
        if (a.equals(R_3)){
            result = REMOTE_PORT3;
        }
        if (a.equals(R_4)){
            result = REMOTE_PORT4;
        }
        return result;
    }

    public String getEmulatorFromPort(String a) {
        String result = "";
        if (a.equals(REMOTE_PORT0)){
            result = R_0;
        }
        if (a.equals(REMOTE_PORT1)){
            result = R_1;
        }
        if (a.equals(REMOTE_PORT2)){
            result = R_2;
        }
        if (a.equals(REMOTE_PORT3)){
            result = R_3;
        }
        if (a.equals(REMOTE_PORT4)){
            result = R_4;
        }
        return result;
    }

    /*public int getModulusOfValue(String str, int n) {
        BigInteger size  = new BigInteger(String.valueOf(n));
        *//*String result = "";
        char[] meschar = str.toCharArray();
        for (int i = 0; i < meschar.length; i++) {
            result += Integer.toBinaryString(meschar[i])+"";
        }
        BigInteger strFromHash = new BigInteger(result);*//*
        BigInteger strFromHash = new BigInteger(str,16);
        int i1 = strFromHash.mod(size).intValue();
        return i1;
    }*/

    public String givelocalmapdump(){
        String result = "";
        for (Map.Entry<String, String> entry : localAllMsg.entrySet()) {
            String key = entry.getKey();
            String value = entry.getValue();
            result = result + key+":"+value+"@";
        }
        Log.v("Local Map Dump",result);
        return result;
    }

    public ConcurrentHashMap<String,String> getlocalmapdump(String a){
        ConcurrentHashMap<String,String> x = new ConcurrentHashMap<String, String>();
        String[] keyvalPairs = a.split("@");
        for (int i=0;i<keyvalPairs.length;i++){
            String[] d = keyvalPairs[i].split(":");
            for (int j=0;j<d.length;j++){
                x.put(d[0],d[1]);
            }
        }
        Log.v("HashMap is:",x.toString());
        return x;
    }
}

