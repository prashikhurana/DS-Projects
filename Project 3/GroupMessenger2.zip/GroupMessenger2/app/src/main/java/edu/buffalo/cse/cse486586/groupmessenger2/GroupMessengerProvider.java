package edu.buffalo.cse.cse486586.groupmessenger2;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.database.Cursor;
import android.net.Uri;
import android.util.Log;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import android.database.MatrixCursor;
import java.io.*;

/**
 * GroupMessengerProvider is a key-value table. Once again, please note that we do not implement
 * full support for SQL as a usual ContentProvider does. We re-purpose ContentProvider's interface
 * to use it as a key-value table.
 * 
 * Please read:
 * 
 * http://developer.android.com/guide/topics/providers/content-providers.html
 * http://developer.android.com/reference/android/content/ContentProvider.html
 * 
 * before you start to get yourself familiarized with ContentProvider.
 * 
 * There are two methods you need to implement---insert() and query(). Others are optional and
 * will not be tested.
 * 
 * @author stevko
 *
 */
public class GroupMessengerProvider extends ContentProvider {

    @Override
    public int delete(Uri uri, String selection, String[] selectionArgs) {
        // You do not need to implement this.
        return 0;
    }

    @Override
    public String getType(Uri uri) {
        // You do not need to implement this.
        return null;
    }

    @Override
    public Uri insert(Uri uri, ContentValues values) {
        String urit = uri.toString();
        //Log.v("urit", urit.toString());
        String test = values.toString();
        //Log.v("test",test);

        String key = "";
        String value = "";


        String[] valar = test.split(" ");
        value = valar[0].substring(6, valar[0].length());
        key = valar[1].substring(4, valar[1].length());

        //Log.v("value",value);
        //Log.v("key",key);

        String filename = getContext().getCacheDir().getPath() + "/" + key;
//Log.v("filename",filename);

        File file = new File(filename);
        //Log.v("FileName in INSERt", filename);

        File f = new File(filename);
        if (f.exists()) {
            try {
                FileWriter writer = new FileWriter(filename);
                writer.write(value);
                writer.flush();
                writer.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        } else {
            try {
                f.createNewFile();
                FileWriter writer = new FileWriter(filename);
                writer.write(value);
                writer.flush();
                writer.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        //Log.v("PROVIDER file:",filename);
        //Log.v("insert", values.toString());

        //urit = urit+"/"+key;
        //Log.v("urit", urit.toString());
        //Uri furi = Uri.parse(urit);
        //Log.v("furi after parsing urit", furi.toString());

        //Log.v("furi", furi.toString());

        //return furi;

        Log.v("insert", values.toString());
        return uri;
    }

    @Override
    public boolean onCreate() {
        // If you need to perform any one-time initialization task, please do it here.
        return false;
    }

    @Override
    public int update(Uri uri, ContentValues values, String selection, String[] selectionArgs) {
        // You do not need to implement this.
        return 0;
    }

    @Override
    public Cursor query(Uri uri, String[] projection, String selection, String[] selectionArgs,
                        String sortOrder) {
        MatrixCursor cursorz = new MatrixCursor(new String[]{"key","value"});
        MatrixCursor.RowBuilder rowB = cursorz.newRow();
        String values = "";
        //Log.v("selection",selection);
        String filename;
        filename = getContext().getCacheDir().getPath()+"/"+selection;
        //Log.v("filename",filename);
        try{
            int i;
            String s = "";
            FileReader reader = new FileReader(filename);
            //Log.v("FIle Found here", s);
            while ((i = reader.read()) != -1) {
                s = s + Character.toString((char) i);
            }
            Log.v("s", s);
            values = s;
            //Log.v("selection in PROVIDER", selection);
            //Log.v("values in PROVIDER", values);
            rowB.add("key", selection);
            rowB.add("value", values);
            //Log.i("TEST", "("+cursorz.getString(0)+", "+cursorz.getString(1)+")");
            reader.close();
        }catch(IOException e){
            Log.v("QUerying data", selection);
            rowB.add("key", selection);
            rowB.add("value", "N/A");
            //e.printStackTrace();
            return cursorz;
        }
        //cursorz.addRow(new String[]{selection,values});
        //Log.v("query test cursor",cursor.getString(0));
        /*
         * TODO: You need to implement this method. Note that you need to return a Cursor object
         * with the right format. If the formatting is not correct, then it is not going to work.
         *
         * If you use SQLite, whatever is returned from SQLite is a Cursor object. However, you
         * still need to be careful because the formatting might still be incorrect.
         *
         * If you use a file storage option, then it is your job to build a Cursor * object. I
         * recommend building a MatrixCursor described at:
         * http://developer.android.com/reference/android/database/MatrixCursor.html
         */
        //Log.v("query at the end", selection);
        return cursorz;
    }
}
