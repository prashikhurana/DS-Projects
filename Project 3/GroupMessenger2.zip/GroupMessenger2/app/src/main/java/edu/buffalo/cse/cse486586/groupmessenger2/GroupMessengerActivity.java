package edu.buffalo.cse.cse486586.groupmessenger2;

import android.app.Activity;
import android.content.ContentValues;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.view.Menu;
import android.widget.TextView;

import android.content.Context;
import android.os.AsyncTask;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.view.View;
import android.widget.EditText;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.lang.reflect.Array;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.net.UnknownHostException;
import java.util.*;
import java.io.*;
import java.util.concurrent.PriorityBlockingQueue;
import java.util.concurrent.TimeUnit;

/**
 * GroupMessengerActivity is the main Activity for the assignment.
 *
 * @author stevko
 *
 */
public class GroupMessengerActivity extends Activity {

    static final String TAG = GroupMessengerActivity.class.getSimpleName();
    static final String REMOTE_PORT0 = "11108";
    static final String REMOTE_PORT1 = "11112";
    static final String REMOTE_PORT2 = "11116";
    static final String REMOTE_PORT3 = "11120";
    static final String REMOTE_PORT4 = "11124";
    static final String providerUris = "content://edu.buffalo.cse.cse486586.groupmessenger2.provider";
    static final int SERVER_PORT = 10000;
    Uri providerUri = Uri.parse(providerUris);

    int failedNode = 4;
    int nofailedNode = 5;
    public volatile int num = -1;
    int key = 0;
    String[] ports = new String[]{REMOTE_PORT0, REMOTE_PORT1, REMOTE_PORT2, REMOTE_PORT3, REMOTE_PORT4};

    private static final String test ="test";
    ContentValues keyValueToInsert = new ContentValues();
    public final List<Integer> allSeq = new ArrayList<Integer>();
    public volatile int seq = -1;

    //public final Node testn = new Node(-10,"-10","","-10");
    public final String alpha = "only for seq &num";

    //PriorityQueue<Node> pq = new PriorityQueue<Node>(10000, new NodeComparator());
    public PriorityBlockingQueue<Node> pq = new PriorityBlockingQueue<Node>(10000, new NodeComparator());
    Set<Node> l11 = new HashSet<Node>();
    Set<Node> l1 = Collections.synchronizedSet(l11);
    //CopyOnWriteArrayList<Node> l1 = new CopyOnWriteArrayList<Node>();
    HashMap<Integer, List<String>> fifolist = new HashMap<Integer, List<String>>();
    HashMap<Integer, List<String>> serverbuffer = new HashMap<Integer, List<String>>();
    public final LinkedHashMap<Integer, String> store = new LinkedHashMap<Integer, String>();
    HashMap<Integer,String> fstore = new HashMap<Integer, String>();
    public final HashMap<Integer,Integer> portseq = new HashMap<Integer, Integer>();
    Socket[] sockar = new Socket[5];
    int x;
    public final List<Integer> expec = new ArrayList<Integer>();
    List<Integer> expport = new ArrayList<Integer>();
    public final HashMap<String, Integer> FailedMsg = new HashMap<String, Integer>();
    ArrayList<String> portsList = new ArrayList<String>(
            Arrays.asList(REMOTE_PORT0,REMOTE_PORT1, REMOTE_PORT2, REMOTE_PORT3,REMOTE_PORT4));
    public volatile String gfailed = "";
    public volatile int failedNodePort = -1;
    public volatile boolean isNodeFailed = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_group_messenger);

        /*
         * TODO: Use the TextView to display your messages. Though there is no grading component
         * on how you display the messages, if you implement it, it'll make your debugging easier.
         */
        final EditText editText = (EditText) findViewById(R.id.editText1);
        TextView tv = (TextView) findViewById(R.id.textView1);
        tv.setMovementMethod(new ScrollingMovementMethod());


        /*
         * Registers OnPTestClickListener for "button1" in the layout, which is the "PTest" button.
         * OnPTestClickListener demonstrates how to access a ContentProvider.
         */
        findViewById(R.id.button1).setOnClickListener(
                new OnPTestClickListener(tv, getContentResolver()));

        TelephonyManager tel = (TelephonyManager)this.getSystemService(Context.TELEPHONY_SERVICE);
        String portStr = tel.getLine1Number().substring(tel.getLine1Number().length()-4);
        final String myPort = String.valueOf(Integer.parseInt(portStr)*2);

        try{
            ServerSocket serverSocket = new ServerSocket(SERVER_PORT);
            new ServerTask().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR,serverSocket);
        }catch (IOException e){
            Log.e(TAG,"Can't create Server Socket");
        }

        findViewById(R.id.button4).setOnClickListener(
                new View.OnClickListener(){
                    @Override
                    public void onClick (View view){
                        String message = editText.getText().toString()+"\n";
                        Log.i("Hello",message);
                        new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR,message,myPort);
                        editText.setText("");
                    }
                }
        );

        /*
         * TODO: You need to register and implement an OnClickListener for the "Send" button.
         * In your implementation you need to get the message from the input box (EditText)
         * and send it to other AVDs.
         */
    }
    private class ServerTask extends AsyncTask<ServerSocket,String,Void>{
        @Override
        protected Void doInBackground(ServerSocket... sockets) {
            ServerSocket serverSocket = sockets[0];
            //int seq = -1;
            //int num = -1;
            String strin;
            while (true) {
                try {
                    Socket socket = serverSocket.accept();
                    //socket.setSoTimeout(5000);
                    //synchronized (socket) {
                        Log.v("Enterered the server", "Server Thread");
                        if (socket.isConnected()) {
                            ObjectInputStream in = new ObjectInputStream(socket.getInputStream());
                            String inputt = (String) in.readObject();
                            if (inputt == null) {
                                break;
                            }
                            if (inputt != null) {
                                //synchronized (Integer.toString(seq)+Integer.toString(num)){
                                Log.v("Getting input server", inputt);
                                String[] t = inputt.split(",");
                                Log.v("Getting after splitting", t[0] + t[1]);
                                String msg = "";
                                String port = "";
                                String sport = "";
                                if (t.length == 3) {

                                    msg = t[0];
                                    port = t[1];
                                    sport = t[2];
                                    if (!sport.equals(gfailed)) {
                                        Log.v("1st Msg & Port", msg + "+ TO: " + port + "+ FROM: " + sport);
                                        try {
                                            //synchronized (Integer.toString(num)) {
                                            //synchronized (Integer.toString(seq)) {
                                            ObjectOutputStream oos1 = new ObjectOutputStream(socket.getOutputStream());
                                            /*if (sport != port) {
                                                seq++;
                                            }*/
                                            seq = seq + 1;
                                            Node n1 = new Node(seq, port, msg, sport);
                                            Log.v("First Proposal from S", "PORT:" + port + " PROP:" + n1.number + " MDG:" + n1.message);
                                            updatePQ(n1, false, -1);
                                            oos1.writeObject(n1.send(n1) + "," + num);
                                            oos1.close();
                                            //}
                                            //}
                                            publishProgress(inputt);
                                        } catch (IOException e) {
                                            e.printStackTrace();
                                            //Log.v("Server Proposal Issue", "TEST");
                                        }catch (Exception e){
                                            e.printStackTrace();
                                        }
                                    }
                                    //}
                                } else if (t.length >= 4) {
                                    //synchronized (Integer.toString(num)) {
                                    //synchronized (Integer.toString(seq)) {
                                    msg = t[0];
                                    String mport = t[1];
                                    int numx = Integer.parseInt(t[2].trim());

                                    sport = t[3];
                                    int toport = Integer.parseInt(t[5].trim());
                                    if (Integer.parseInt(sport) != toport) {
                                        num = numx;
                                    }
                                    Boolean ready = Boolean.valueOf(t[4]);
                                    Log.v("Server MaxMsg & Port", "MSG: " + msg + " MAXPORT:" + mport + " " + "MAX PROP" + Integer.toString(numx) + " " + Boolean.toString(ready));
                                    Node n1 = new Node((numx), mport, msg, sport, ready);
                                    updatePQ(n1, true, Integer.parseInt(mport.trim()));
                                    //updateList(n1);
                                    printPq(pq);
                                    int failedN = 0;
                                    String failedp = "";
                                    if (t[6] != null && !t[6].equals("300")) {
                                        failedN = Integer.parseInt(t[6]);
                                        Log.v("FAILEDSERVERNODE", failedp);
                                        gfailed = failedp;
                                    }
                                    if (!sport.equals(gfailed)) {
                                        //Iterator<Node> it
                                        //r = pq.iterator();
                                        Log.v("SERVER size of pq", Integer.toString(pq.size()));
                                        try {
                                            while (pq.size() != 0) {
                                                Node n2 = pq.peek();
                                            /*if (failedN!=300 && fifolist.get(failedN)!=null && fifolist.get(failedN).contains(n2)){
                                                pq.take();
                                            }else*/
                                                if (n2.ready && n2.maxport != 0) {
                                                    publishProgress(key + "," + n2.message);
                                                    key = key + 1;
                                                    pq.take();
                                                } else {
                                                    break;
                                                }
                                            }
                                        } catch (Exception e) {
                                            Log.v("Difficult in reading", "PQ");
                                        }
                                    }
                                }
                            }
                            //}
                            //}
                            //}
                        }
                    } catch(ClassNotFoundException e){
                        Log.e(TAG, "ClassNotFound");
                        e.printStackTrace();
                        break;
                    }catch(EOFException e){
                        Log.v("EOF exception", "server");
                        e.printStackTrace();
                        continue;
                    }catch(SocketTimeoutException e){
                        Log.e("Socket Exception", "Server");
                        e.printStackTrace();
                        continue;
                    } catch(Exception e){
                        Log.v("Exception", "Server");
                        e.printStackTrace();
                        break;
                    }
                }
            return null;
        }


        protected void onProgressUpdate(String...strings){

            String strReceived = strings[0].trim();

            TextView tv = (TextView) findViewById(R.id.textView1);
            String[] finals = strReceived.split(",");
            if (finals.length == 3){
                //Log.v("Increase Seq No",finals[0]+finals[1]+finals[2]);
                addtoFiFo(finals[2],finals[0]);
                addtoserverbuff(finals[2],finals[0]);
            }else if (finals.length == 2){
                tv.append(strReceived + "\t\n");
            }
            int flen = finals.length ;
            //Log.v("Finals Length", Integer.toString(flen));


            if (finals.length == 2) {
                printHashMap(fifolist);
                keyValueToInsert.put("key", Integer.toString(Integer.parseInt(finals[0])));
                Log.v("Key in INSERT", finals[0]);
                keyValueToInsert.put("value", finals[1]);
                Log.v("Value in INSERT", finals[1]);

                Uri newUri = getContentResolver().insert(
                        providerUri,    // assume we already created a Uri object with our provider URI
                        keyValueToInsert
                );
                String newuri = newUri.toString();
                String filename = "GroupMessengerActivityOutput";
                String string = strReceived + "\n";
                FileOutputStream outputStream;
                try {
                    outputStream = openFileOutput(filename, Context.MODE_PRIVATE);
                    outputStream.write(string.getBytes());
                    outputStream.close();
                } catch (Exception e) {
                    Log.e(TAG, "File write failed");
                }
            }

            /*
             * The following code creates a file in the AVD's internal storage and stores a file.
             *
             * For more information on file I/O on Android, please take a look at
             * http://developer.android.com/training/basics/data-storage/files.html
             */

            return;
        }
    }

    private class ClientTask extends AsyncTask<String, Void, Void>{
        @Override
        protected Void doInBackground(String... msgs) {

            //Log.v("remoteport", remoteport);

            //String[] ports = new String[]{REMOTE_PORT0, REMOTE_PORT1};
            String myport = msgs[1];
            String msgToSend = msgs[0];
            //Log.v("msgToSend", msgToSend);

            Log.v("Msg to SEND:",msgToSend);
            try {
                //synchronized (test) {
                    Socket s1 = null, s2 = null, s3 = null, s4 = null, s5 = null;
                        Log.v("Socket1","Socket1");
                        s1 = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}), Integer.parseInt(REMOTE_PORT0));

                        Log.v("Socket2","Socket2");
                        s2 = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}), Integer.parseInt(REMOTE_PORT1));

                        Log.v("Socket3","Socket3");
                        s3 = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}), Integer.parseInt(REMOTE_PORT2));

                        Log.v("Socket4","Socket4");
                        s4 = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}), Integer.parseInt(REMOTE_PORT3));

                        Log.v("Socket5","Socket5");
                        s5 = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}), Integer.parseInt(REMOTE_PORT4));

                    String msgToSend1 = "", msgToSend2 = "", msgToSend3 = "", msgToSend4 = "", msgToSend5 = "";

                        ObjectOutputStream oos1 = new ObjectOutputStream(s1.getOutputStream());
                        msgToSend1 = msgToSend.substring(0, msgToSend.length() - 1) + "," + REMOTE_PORT0 + "," + myport;
                        oos1.writeObject(msgToSend1);
                        oos1.flush();

                        ObjectOutputStream oos2 = new ObjectOutputStream(s2.getOutputStream());
                        msgToSend2 = msgToSend.substring(0, msgToSend.length() - 1) + "," + REMOTE_PORT1 + "," + myport;
                        oos2.writeObject(msgToSend2);
                        oos2.flush();

                        ObjectOutputStream oos3 = new ObjectOutputStream(s3.getOutputStream());
                        msgToSend3 = msgToSend.substring(0, msgToSend.length() - 1) + "," + REMOTE_PORT2 + "," + myport;
                        oos3.writeObject(msgToSend3);
                        oos3.flush();

                        ObjectOutputStream oos4 = new ObjectOutputStream(s4.getOutputStream());
                        msgToSend4 = msgToSend.substring(0, msgToSend.length() - 1) + "," + REMOTE_PORT3 + "," + myport;
                        oos4.writeObject(msgToSend4);
                        oos4.flush();
                    //}
                    //Log.v("msgToSend4",msgToSend4);

                    //if (s5 != null) {
                        ObjectOutputStream oos5 = new ObjectOutputStream(s5.getOutputStream());
                        msgToSend5 = msgToSend.substring(0, msgToSend.length() - 1) + "," + REMOTE_PORT4 + "," + myport;
                        oos5.writeObject(msgToSend5);
                        oos5.flush();
                    //}
                    //Log.v("msgToSend5",msgToSend5);

                    Log.v("Msgs:", msgToSend + " " + msgToSend1 + " " + msgToSend2 + " " + msgToSend3 + " " + msgToSend4 + " " + msgToSend5);

                    Node n1 = null;
                    Node n2 = null;
                    Node n3 = null;
                    Node n4 = null;
                    Node n5 = null;
                    String inp1 = null;
                    String inp2 = null;
                    String inp3 = null;
                    String inp4 = null;
                    String inp5 = null;

                    //s1.setSoTimeout(5000);
                    //if (s1 != null) {
                        try {
                            //s1.setSoTimeout(500);
                            //s1.setSoTimeout(500);
                            ObjectInputStream in1 = new ObjectInputStream(s1.getInputStream());
                            inp1 = (String) in1.readObject();
                            //Log.v("INPUT FROM SERVER 1",inp1);
                            //addingClientMsgToList((inp1 + "," + myport));
                            n1 = getNodeforClient(inp1 + "," + myport);
                            //s1.setSoTimeout(500);
                            Log.v("Client", "1st");
                            //addToCLN(clientNode,getNodeforClient(inp1 + "," + myport));
                        }
                        catch (IOException e) {
                            e.printStackTrace();
                            Log.v("SocketTimeour", "1st");
                            //s1.close();
                            //s1.shutdownOutput();
                            //s1.shutdownInput();
                            isNodeFailed = true;
                            failedNodePort = Integer.parseInt(REMOTE_PORT0);
                            //s1 = null;
                            Log.v("NodeFailed", "1st");
                        } catch (ClassNotFoundException e) {
                            Log.v("ClassNotFound", "1st");
                        }
                    //}

                    //if (s2 != null) {
                        try {
                            //s2.setSoTimeout(500);
                            ObjectInputStream in2 = new ObjectInputStream(s2.getInputStream());
                            inp2 = (String) in2.readObject();
                            //Log.v("INPUT FROM SERVER 2",inp2);
                            //addingClientMsgToList(inp2 + "," + myport);
                            n2 = getNodeforClient(inp2 + "," + myport);

                            //Log.v("2st socket node", "check");
                        } catch (IOException e) {
                            e.printStackTrace();
                            //Log.v("EnteredsocketTimeout", "CLinet");
                            //s2.close();
                            //s2.shutdownOutput();
                            //s2.shutdownInput();
                            isNodeFailed = true;
                            failedNodePort = Integer.parseInt(REMOTE_PORT1);
                            //s2 = null;
                            //Log.v("2nd NodeFailed", "Client");
                        } catch (ClassNotFoundException e) {
                            //Log.v("Class Not FOund", "Client");
                        } catch (Exception e){
                            e.printStackTrace();
                        }
                    //}

                    //if (s3!=null) {
                        try {
                            //s3.setSoTimeout(500);
                            ObjectInputStream in3 = new ObjectInputStream(s3.getInputStream());
                            inp3 = (String) in3.readObject();
                            //Log.v("INPUT FROM SERVER 3",inp3);
                            //addingClientMsgToList(inp3 + "," + myport);
                            n3 = getNodeforClient(inp3 + "," + myport);

                            //Log.v("3st socket node", "check");
                        } catch (IOException e) {
                            e.printStackTrace();
                            //s3.close();
                            //s3.shutdownOutput();
                            //s3.shutdownInput();
                            //Log.v("Entered socket Timeout", "CLinet");
                            isNodeFailed = true;
                            failedNodePort = Integer.parseInt(REMOTE_PORT2);
                            //s3 = null;
                            //Log.v("3rd Node Failed", "Client");
                        } catch (ClassNotFoundException e) {
                            //Log.v("Class Not FOund", "Client");
                        } catch(Exception e){

                        }
                    //}

                    //if (s4!=null) {
                        try {
                            //s4.setSoTimeout(500);
                            ObjectInputStream in4 = new ObjectInputStream(s4.getInputStream());
                            inp4 = (String) in4.readObject();
                            //Log.v("INPUT FROM SERVER 4",inp4);
                            //addingClientMsgToList(inp4 + "," + myport);
                            n4 = getNodeforClient(inp4 + "," + myport);

                            //Log.v("4st socket node", "check");
                        } catch (IOException e) {
                            e.printStackTrace();
                            //s4.close();
                            //s4.shutdownOutput();
                            //s4.shutdownInput();
                            //Log.v("Entered socket Timeout", "CLinet");
                            isNodeFailed = true;
                            failedNodePort = Integer.parseInt(REMOTE_PORT3);
                            //s4 = null;
                            //Log.v("Node Failed", "Client");
                        } catch (ClassNotFoundException e) {
                            //Log.v("Class Not FOund", "Client");
                        }catch(Exception e){

                        }
                    //}
                    //}
                    //addToCLN(clientNode,getNodeforClient(inp4 + "," + myport));
                    //expec.add(getnum(inp4));
                    //expport.add(getport(inp4));

                    //Log.v("5st socket","check");

                    //while (true) {

                    //if (s5!=null) {
                        try {
                            //s5.setSoTimeout(500);
                            ObjectInputStream in5 = new ObjectInputStream(s5.getInputStream());
                            inp5 = (String) in5.readObject();
                            //Log.v("INPUT FROM SERVER 5",inp5);
                            //addingClientMsgToList(inp5 + "," + myport);
                            n5 = getNodeforClient(inp5 + "," + myport);
                            //
                            //Log.v("5st socket node", "check");
                        } catch (IOException e) {
                            e.printStackTrace();
                            //s5.close();
                            //s5.shutdownOutput();
                            //s5.shutdownInput();
                            //Log.v("Entered socket Timeout", "CLinet");
                            isNodeFailed = true;
                            failedNodePort = Integer.parseInt(REMOTE_PORT4);
                            //s5 = null;
                            //Log.v("Node Failed", "Client");
                        } catch (ClassNotFoundException e) {
                            //Log.v("Class Not FOund", "Client");
                        } catch (Exception e){

                        }
                    //}
                    //}

                    //addToCLN(clientNode,getNodeforClient(inp5 + "," + myport));
                    //expec.add(getnum(inp5));
                    //expport.add(getport(inp5));

                    //getMaxFromNodes(n1,n2,n3,n4,n5);
                    if (!isNodeFailed) {
                        //Log.v("IsNotNodeFailed","Client");
                        Log.v("Input from server:", "1:" + inp1 + " " + "2:" + inp2 + " " + "3:" + inp3 + " " + "4:" + inp4 + " " + "5:" + inp5 + ".");
                    } else if (isNodeFailed) {
                        //synchronized (test){
                            gfailed = Integer.toString(failedNodePort);
                        //}
                        //Log.v("IsNodeFailed","Client");
                        Log.v("Input from server:", "1:" + inp1 + " " + "2:" + inp2 + " " + "3:" + inp3 + " " + "4:" + inp4 + " " + "5:" + inp5 + ".");
                    }
                    Node nr = null;
                    boolean isTrue = false;
                    if (!isNodeFailed && n1!=null && n2!=null && n3!=null && n4!=null && n5!=null) {
                        Log.v("ISNodeFailed False",Boolean.toString(isNodeFailed));
                        List<Double> num1 = new ArrayList<Double>();
                        num1.add(Double.parseDouble(n1.number + "." + n1.port));
                        num1.add(Double.parseDouble(n2.number + "." + n2.port));
                        num1.add(Double.parseDouble(n3.number + "." + n3.port));
                        num1.add(Double.parseDouble(n4.number + "." + n4.port));
                        num1.add(Double.parseDouble(n5.number + "." + n5.port));
                        double maxs = 0;
                        for (int i = 0; i < num1.size(); i++) {
                            if (num1.get(i) > maxs) {
                                maxs = num1.get(i);
                            }
                        }
                        //Log.v("MAXS",Double.toString(maxs));
                        String h = Double.toString(maxs);
                        //Log.v("Print h",h);
                        String h1 = h.substring(0, h.indexOf("."));
                        String h2 = h.substring(h.indexOf(".") + 1, h.length());
                        //Log.v("HI & H2",h1+" & "+h2);
                        nr = new Node(Integer.parseInt(h1.trim()), Integer.toString(n1.port), n1.message, myport, Integer.parseInt(h2));
                        isTrue = true;
                    } else if (isNodeFailed) {
                        Log.v("ISNodeFailed False",Boolean.toString(isNodeFailed));
                        List<Double> num1 = new ArrayList<Double>();
                        Node ln = null;
                        if (n1 != null) {
                            num1.add(Double.parseDouble(n1.number + "." + n1.port));
                            ln = n1;
                        }
                        if (n2 != null) {
                            num1.add(Double.parseDouble(n2.number + "." + n2.port));
                            ln = n2;
                        }
                        if (n3 != null) {
                            num1.add(Double.parseDouble(n3.number + "." + n3.port));
                            ln = n3;
                        }
                        if (n4 != null) {
                            num1.add(Double.parseDouble(n4.number + "." + n4.port));
                            ln = n4;
                        }
                        if (n5 != null) {
                            num1.add(Double.parseDouble(n5.number + "." + n5.port));
                            ln = n5;
                        }
                        double maxs = 0;
                        for (int i = 0; i < num1.size(); i++) {
                            if (num1.get(i) > maxs) {
                                maxs = num1.get(i);
                            }
                        }
                        Log.v("MAXS",Double.toString(maxs));
                        String h = Double.toString(maxs);
                        String h1 = h.substring(0, h.indexOf("."));
                        String h2 = h.substring(h.indexOf(".") + 1, h.length());
                        nr = new Node(Integer.parseInt(h1.trim()), Integer.toString(ln.port), ln.message, myport, Integer.parseInt(h2));
                        isTrue = true;
                    }
                    String sentdata = "-1";
                    if (nr!=null) {
                        sentdata = nr.newsend(nr) + "," + myport + "," + isTrue;
                    }
                    Log.v("Sentdata", sentdata+"\n");
                    Log.v("IsNodeFailed", Boolean.toString(isNodeFailed));
                    Log.v("failedNodePort", Integer.toString(failedNodePort));

                    if (!sentdata.equals("-1")) {
                        if (isNodeFailed) {
                            try {
                                //if (!gfailed.equals(REMOTE_PORT0)) {
                                    Log.v("Socket1", "Socket1");
                                    s1 = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}), Integer.parseInt(REMOTE_PORT0));
                                    ObjectOutputStream oos11 = new ObjectOutputStream(s1.getOutputStream());
                                    oos11.writeObject(sentdata + "," + REMOTE_PORT0 + "," + failedNodePort);
                                    oos11.flush();
                                //}

                                //if (!gfailed.equals(REMOTE_PORT1)) {
                                    Log.v("Socket2", "Socket2");
                                    s2 = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}), Integer.parseInt(REMOTE_PORT1));
                                    ObjectOutputStream oos21 = new ObjectOutputStream(s2.getOutputStream());
                                    oos21.writeObject(sentdata + "," + REMOTE_PORT1 + "," + failedNodePort);
                                    oos21.flush();
                                //}

                                //if (!gfailed.equals(REMOTE_PORT2)) {
                                    Log.v("Sokcet3", "Socket3");
                                    s3 = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}), Integer.parseInt(REMOTE_PORT2));
                                    ObjectOutputStream oos31 = new ObjectOutputStream(s3.getOutputStream());
                                    oos31.writeObject(sentdata + "," + REMOTE_PORT2 + "," + failedNodePort);
                                    oos31.flush();
                                //}

                                //if (!gfailed.equals(REMOTE_PORT3)) {
                                    Log.v("Socket4", "Socket4");
                                    s4 = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}), Integer.parseInt(REMOTE_PORT3));
                                    ObjectOutputStream oos41 = new ObjectOutputStream(s4.getOutputStream());
                                    oos41.writeObject(sentdata + "," + REMOTE_PORT3 + "," + failedNodePort);
                                    oos41.flush();
                                //}

                                //if (!gfailed.equals(REMOTE_PORT4)) {
                                    Log.v("Socket5", "Socket5");
                                    s5 = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}), Integer.parseInt(REMOTE_PORT4));
                                    ObjectOutputStream oos51 = new ObjectOutputStream(s5.getOutputStream());
                                    oos51.writeObject(sentdata + "," + REMOTE_PORT4 + "," + failedNodePort);
                                    oos51.flush();
                                //}

                            } catch (UnknownHostException e) {
                                e.printStackTrace();
                                Log.v("Client", "Unknown host");
                            } catch (IOException e) {
                                e.printStackTrace();
                                Log.v("Clinet", "IOException");
                            } catch (Exception e){
                                e.printStackTrace();
                            }

                        }
                        if (!isNodeFailed) {
                            try {
                                Socket s11 = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}), Integer.parseInt(REMOTE_PORT0));
                                ObjectOutputStream oos11 = new ObjectOutputStream(s11.getOutputStream());
                                oos11.writeObject(sentdata + "," + REMOTE_PORT0 + "," + "300");

                                Socket s21 = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}), Integer.parseInt(REMOTE_PORT1));
                                ObjectOutputStream oos21 = new ObjectOutputStream(s21.getOutputStream());
                                oos21.writeObject(sentdata + "," + REMOTE_PORT1 + "," + "300");

                                Socket s31 = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}), Integer.parseInt(REMOTE_PORT2));
                                ObjectOutputStream oos31 = new ObjectOutputStream(s31.getOutputStream());
                                oos31.writeObject(sentdata + "," + REMOTE_PORT2 + "," + "300");

                                Socket s41 = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}), Integer.parseInt(REMOTE_PORT3));
                                ObjectOutputStream oos41 = new ObjectOutputStream(s41.getOutputStream());
                                oos41.writeObject(sentdata + "," + REMOTE_PORT3 + "," + "300");

                                Socket s51 = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}), Integer.parseInt(REMOTE_PORT4));
                                ObjectOutputStream oos51 = new ObjectOutputStream(s51.getOutputStream());
                                oos51.writeObject(sentdata + "," + REMOTE_PORT4 + "," + "300");

                            } catch (UnknownHostException e) {
                                e.printStackTrace();
                                Log.v("Client", "Unknown host");
                            } catch (IOException e) {
                                e.printStackTrace();
                                Log.v("Clinet", "IOException");
                            } catch (Exception e){
                                e.printStackTrace();
                            }

                        }
                    }
                }catch (IOException e){
                e.printStackTrace();
                Log.v("In client","IO");
            } catch (Exception e){
                e.printStackTrace();
            }
            return null;
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.activity_group_messenger, menu);
        return true;
    }

    public void updatePQ(Node n1,boolean x, int portss){
        synchronized (pq) {
            boolean addtoPq = false;
            boolean updaten = false;
            boolean updatenum = false;
            //Log.v("In update PQ", "Prashi");
            Iterator<Node> itr = pq.iterator();
            if (pq.size() == 0) {
                addtoPq = true;
            } else {
                Node n = null;
                while (itr.hasNext()) {
                    Node temp = itr.next();
                    //Log.v("N.message n1.message", temp.message + n1.message);
                    //if (temp.sentport == n1.sentport) {
                        if (temp.message.equals(n1.message)) {
                            //Log.v("Both are eqaul","temp and n1");
                            //Log.v("N.message n1.message", temp.message + n1.message);
                            n = temp;
                            updaten = true;
                            addtoPq = false;
                            break;
                        } else {
                            //Log.v("Adding Node n1 to PQ", n1.send(n1));
                            addtoPq = true;
                        }

                    /*if (temp.number==n1.number){
                        n = temp;
                        addtoPq = true;
                        updatenum = true;
                    }*/
                }
                if (updaten) {
                    //Log.v("N.message = n1.message", n.message + "||" +n1.message);
                    //Log.v("N.no n1.bo", Integer.toString(n.number) + Integer.toString(n1.number));
                    if (n1.number >= n.number) {
                        //Log.v("n1 no > n no",n1.number+"||"+n.number);
                        if (x){
                            //Log.v("X is ture","X");
                            n1.ready = true;
                            n1.maxport = portss;
                        }
                        pq.remove(n);
                        pq.add(n1);
                        //n.maxport = n1.maxport;
                        //Log.v("FInal n",n.newsend(n));
                    }
                }
            }
            if (addtoPq){
                if (x){
                    n1.setReady(true);
                    n1.setMaxPort(portss);
                }
                pq.add(n1);
            }
        }
    }

    public class Node {
        String message;
        int number;
        int port;
        Set<Integer> portsList = new HashSet<Integer>();
        boolean ready = false;
        int sentport;
        int maxport;

        Node(int a,String b, String m, String sport){
            Log.v("Created Node with", "MSG:"+a+"PORT:"+b+"Msg:"+m+"Sendingport:"+sport);
            this.number = a;
            this.port = Integer.parseInt(b);
            this.message = m;
            this.portsList.add(port);
            this.sentport = Integer.parseInt(sport);
        }

        Node(int a,String b, String m, String sport, Boolean ready){
            //Log.v("Created Node variable", "MSG:"+a+"PORT:"+b+"Msg:"+m+" "+Boolean.toString(ready));
            number = a;
            port = Integer.parseInt(b);
            message = m;
            portsList.add(port);
            sentport = Integer.parseInt(sport);
            this.ready = ready;
        }

        Node(int a,String b, String m, String sport, Integer maxport){
            Log.v("Created Node with", "No.:"+a+" PORT:"+b+" Msg:"+m+" Sendingport:"+sport+ " MaxPort:"+maxport);
            this.number = a;
            this.port = Integer.parseInt(b);
            this.message = m;
            this.portsList.add(port);
            this.sentport = Integer.parseInt(sport);
            this.maxport = maxport;
        }

        public void setMaxPort(int maxport){
            this.maxport = maxport;
        }

        public void setReady(boolean ready){
            this.ready = ready;
        }

        public void setMessage(String msg){
            this.message = msg;
        }

        public void setMaxport(int mxport){
            this.maxport = mxport;
        }

        public void setNumber(int no){
            this.number = no;
        }

        public String send(Node n1){
            return n1.message+","+n1.port+","+n1.number+"\n";
        }

        public String newsend(Node n1){
            return n1.message+","+n1.maxport+","+n1.number;
        }

        public String printPortList(Set<Integer> portsList){
            return printsetint(portsList);
        }
    }

    public void tryadding(Set<Node> l1, Node n1){
        synchronized (l1) {
            //Log.v("Try Adding To CLient", "SizeList"+Integer.toString(l1.size())+" " + n1.send(n1)+n1.sentport);
            if (l1.size() == 0) {
                l1.add(n1);
            } else {
                boolean match = false;
                Node n2 = null;
                for (Iterator<Node> i = l1.iterator(); i.hasNext(); ) {
                    Node temp = i.next();
                    //Log.v("Iterating the List", n2.send(n2));
                    //Log.v("Trying to add Node", n1.send(n1));
                        if (n1.sentport==temp.sentport && n1.message.equals(temp.message)) {
                            n2 = temp;
                            match = true;
                            break;
                        }
                }
                if (match){
                    if (n1.number>n2.number){
                        n2.number = n1.number;
                        n2.maxport = n1.maxport;
                    }else if (n1.number==n2.number){
                        if (n1.port > n2.port){
                            n2.maxport = n1.maxport;
                        }
                        n2.portsList.add(n1.port);
                        n1.portsList.add(n2.port);
                    }
                    //Log.v("n1.message = n2.message", n1.message + " " + n2.message);
                    //Log.v("Addingn2.port n1'sport", n1.printPortList(n1.portsList));
                }else {
                    l1.add(n1);
                }
            }
        }
        printclientList(l1);
    }



    public void printclientList(Set<Node> li){
        //Log.v("Printing Client List","List");
        String res = li.size()+" ";
        for (Iterator<Node> i = l1.iterator(); i.hasNext(); ) {
            Node n2 = i.next();
            //res = res + "Sent from:"+n2.sentport +" Message:"+n2.message +" Final_no: "+n2.number+ " Ports:" + n2.printPortList(n2.portsList);
            res = res+"Sent:"+n2.sentport+"/"+"Message:"+n2.message+"/"+"FinalNo:"+n2.number+"/"+"MaxPort"+n2.maxport+"/"+"Ports:"+n2.printPortList(n2.portsList)+"/";
            res = res + " ....";
        }
        //Log.v("Client List", res);
    }

    class NodeComparator implements Comparator<Node>{
        public int compare(Node s1, Node s2) {
            if (!s1.message.equals(s2.message)){
                if (s2.number > s1.number){
                    return -1;
                }else if(s1.number > s2.number){
                    return 1;
                }if (s1.number==s2.number){
                    if (s2.maxport>s1.maxport){
                        return -1;
                    }else if (s1.maxport>s2.maxport){
                        return 1;
                    }
                }
                //Log.v("s1.msg != s2.msg",s1.message+" "+s2.message);
                return 1;
            }
            return 0;
        }
    }

    public boolean isReady(Node n1){
        boolean isr = false;
        if (n1.ready){
            isr = true;
        }
        //Log.v("ISR",Boolean.toString(isr));
        return isr;
    }

    public String printList(List l1){
        String result = "";
        for(int i=0;i<l1.size();i++){
            result = result+(l1.get(i));
        }
        //Log.v("Print List is",result);
        return result;
    }

    public String printsetint(Set s1){
        String result = "";
        if (s1!=null && s1.size()!=0) {
            List<Integer> aList = new ArrayList<Integer>(s1);
            for (Integer x : aList) {
                result = result + " " + Integer.toString(x);
            }
            //Log.v("Set is", result);
        }
        return result;
    }

    public String printsetNode(Set s1){
        String result = "";
        if (s1!=null && s1.size()!=0) {
            List<Node> aList = new ArrayList<Node>(s1);
            for (Node x : aList) {
                result = result + " " + x.newsend(x);
            }
            //Log.v("Set is", result);
        }
        return result;
    }


    public void addingClientMsgToList(String s){
        //Log.v("Adding msg to client","CLIENT");
        synchronized (l1) {
            //Log.v("Message to add", s);
            String g[] = s.split(",");
            if (g[0] != "" && g[1] != "" && g[2] != "") {
                //Log.v("Node", "Number" + g[2].trim() + " Message" + g[0] + " Port" + g[1] + " Sent" + g[4]);
                Node n1 = new Node(Integer.parseInt(g[2].trim()), g[1], g[0], g[4]);
                n1.setMaxPort(Integer.parseInt(g[1]));
                tryadding(l1, n1);
            }
        }
    }

    public Node getNodeforClient(String s){
        Node n1 = null;
        synchronized (test) {
            if(!s.isEmpty()) {
                //Log.v("Message to add", s);
                String g[] = s.split(",");
                if (g.length>=3){
                if (g[0] != "" && g[1] != "" && g[2] != "") {
                    //Log.v("Node", "Number" + g[2].trim() + "Message" + g[0] + "Port" + g[1] + "Sent" + g[4]);
                    n1 = new Node(Integer.parseInt(g[2].trim()), g[1], g[0], g[4]);
                    n1.setMaxPort(Integer.parseInt(g[1]));
                }
                }
            }
        }
        return n1;
    }

    public String printPq(PriorityBlockingQueue<Node> pq){
        //Log.v("Printing PQ","PQ");
        String res = "";
        Iterator<Node> itr = pq.iterator();
        while (itr.hasNext()) {
            Node n1 = itr.next();
            res = res +" "+"Msg:"+n1.message+" MaxPort"+n1.maxport+" Number"+n1.number+"\n"+" SenderPort:"+n1.sentport+"\n";
        }
        Log.v("PriorityQ",res);
        return res;
    }

    public void addtoFiFo(String port, String msgToSend){
        synchronized (fifolist) {
            //Log.v("Adding FIFIO list", msgToSend + " from " + port);
            //printHashMap(fifolist);
            if (fifolist.containsKey(Integer.parseInt(port))) {
                //Log.v("List has port", port);
                List<String> targetSet = fifolist.get(Integer.parseInt(port));
                printList(targetSet);
                targetSet.add(targetSet.size(),msgToSend);
                //Collections.reverse(targetSet);
                fifolist.put(Integer.parseInt(port), targetSet);
            } else {
                //Log.v("No such entry",port);
                List<String> targetSet = new ArrayList<String>();;
                targetSet.add(msgToSend);
                fifolist.put(Integer.parseInt(port), targetSet);
            }
        }
        printHashMap(fifolist);
    }

    public void addtoserverbuff(String port, String msgToSend){
        synchronized (serverbuffer) {
            //Log.v("Adding serverbuffer", msgToSend + " from " + port);
            //printHashMap(serverbuffer);
            if (serverbuffer.containsKey(Integer.parseInt(port))) {
                //Log.v("List has port", port);
                List<String> targetSet = serverbuffer.get(Integer.parseInt(port));
                //printList(targetSet);
                targetSet.add(targetSet.size(),msgToSend);
                //Collections.reverse(targetSet);
                serverbuffer.put(Integer.parseInt(port), targetSet);
            } else {
                //Log.v("No such entry",port);
                if (fifolist.containsKey(Integer.getInteger(port))){
                    List<String> targetSet = fifolist.get(Integer.parseInt(port));
                    if (targetSet.indexOf(msgToSend)!=-1){
                        targetSet.add(targetSet.indexOf(msgToSend),msgToSend);
                        serverbuffer.put(Integer.parseInt(port), targetSet);
                    }
                }else{
                    List<String> targetSet = new ArrayList<String>();
                    targetSet.add(0,msgToSend);
                    serverbuffer.put(Integer.parseInt(port), targetSet);
                }
            }
        }
        printHashMap(serverbuffer);
    }

    public void printHashMap(HashMap<Integer, List<String>>Li ){
        Log.v("HashMap is",(Collections.singletonList(Li)).toString());
    }
}
