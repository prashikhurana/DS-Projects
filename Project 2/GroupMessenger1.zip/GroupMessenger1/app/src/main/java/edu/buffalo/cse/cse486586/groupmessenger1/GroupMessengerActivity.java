package edu.buffalo.cse.cse486586.groupmessenger1;

import android.app.Activity;
import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.Telephony;
import android.telephony.TelephonyManager;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.content.*;
import android.net.*;
import java.io.ObjectOutputStream;
import java.io.FileOutputStream;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;

/**
 * GroupMessengerActivity is the main Activity for the assignment.
 * 
 * @author stevko
 *
 */
public class GroupMessengerActivity extends Activity {

    static final String TAG = GroupMessengerActivity.class.getSimpleName();
    static final String REMOTE_PORT0 = "11108";
    static final String REMOTE_PORT1 = "11112";
    static final String REMOTE_PORT2 = "11116";
    static final String REMOTE_PORT3 = "11120";
    static final String REMOTE_PORT4 = "11124";
    static final String providerUris = "content://edu.buffalo.cse.cse486586.groupmessenger1.provider";
    static final int SERVER_PORT = 10000;
    Uri providerUri = Uri.parse(providerUris);

    private static final String test ="test";
    ContentValues keyValueToInsert = new ContentValues();
    public int seq = 0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_group_messenger);

        /*
         * TODO: Use the TextView to display your messages. Though there is no grading component
         * on how you display the messages, if you implement it, it'll make your debugging easier.
         */
        final EditText editText = (EditText) findViewById(R.id.editText1);
        TextView tv = (TextView) findViewById(R.id.textView1);
        //tv.append(editText.getText().toString()+"\n");
        tv.setMovementMethod(new ScrollingMovementMethod());
        
        /*
         * Registers OnPTestClickListener for "button1" in the layout, which is the "PTest" button.
         * OnPTestClickListener demonstrates how to access a ContentProvider.
         */
        findViewById(R.id.button1).setOnClickListener(
                new OnPTestClickListener(tv, getContentResolver()));
        
        /*
         * TODO: You need to register and implement an OnClickListener for the "Send" button.
         * In your implementation you need to get the message from the input box (EditText)
         * and send it to other AVDs.
         */
        TelephonyManager tel = (TelephonyManager)this.getSystemService(Context.TELEPHONY_SERVICE);
        String portStr = tel.getLine1Number().substring(tel.getLine1Number().length()-4);
        final String myPort = String.valueOf(Integer.parseInt(portStr)*2);

        try{
            ServerSocket serverSocket = new ServerSocket(SERVER_PORT);
            new ServerTask().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR,serverSocket);
        }catch (IOException e){
            Log.e(TAG,"Can't create Server Socket");
        }

        findViewById(R.id.button4).setOnClickListener(
                new View.OnClickListener(){
                    @Override
                    public void onClick (View view){
                        String message = editText.getText().toString()+"\n";
                        new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR,message,myPort);
                        editText.setText("");
                    }
                }
        );
    }

    private class ServerTask extends AsyncTask<ServerSocket,String,Void>{
        @Override
        protected Void doInBackground(ServerSocket...sockets){
            Log.v("Inside server Thread","yes");
            String inputte = "";
            try{
                while(true) {

                    ServerSocket serverSocket = sockets[0];
                    synchronized (serverSocket) {

                        Socket socket = serverSocket.accept();
                        //Socket socket = serverSocket.accept();
                        ObjectInputStream ois = new ObjectInputStream(socket.getInputStream());
                        //get the values from the keys
                        //synchronized (socket) {
                        inputte = (String) ois.readObject();
                        if (inputte == null || inputte.isEmpty()) {
                            break;
                        }
                        String seqs = Integer.toString(seq);
                        try {
                            Log.v("SERVER THREAD SOCkPORT", Integer.toString(socket.getPort()));
                            Log.v("SERVER THREAD LocalPORT", Integer.toString(socket.getLocalPort()));

                            Log.v("SERVER THREAD", inputte);
                            publishProgress(inputte);

                        } catch (Exception e) {
                            Log.e(TAG, "File write failed");
                        }
                        ois.close();
                    }
                }
            }catch (IOException e){
                Log.e(TAG, "Cant read message");
            }catch (ClassNotFoundException e){
                Log.e(TAG, "Cant read message");
            }/*catch (InterruptedException e){
                Log.e(TAG, "Interrupted Exception e");
            }*/
            return null;
        }

        protected void onProgressUpdate(String...strings){

            String strReceived = strings[0].trim();
            TextView tv = (TextView) findViewById(R.id.textView1);
            tv.append(strReceived + "\t\n");

            //Log.v("URI",providerUri.toString());


            keyValueToInsert.put("key", Integer.toString(seq));
            Log.v("Key in INSERT",  Integer.toString(seq));
            keyValueToInsert.put("value", strReceived);
            Log.v("Value in INSERT", strReceived);
            seq++;

            Uri newUri = getContentResolver().insert(
                    providerUri,    // assume we already created a Uri object with our provider URI
                    keyValueToInsert
            );
            String newuri = newUri.toString();


            String filename = "GroupMessengerActivityOutput";
            String string = strReceived + "\n";
            FileOutputStream outputStream;
            try {
                outputStream = openFileOutput(filename, Context.MODE_PRIVATE);
                outputStream.write(string.getBytes());
                outputStream.close();
            } catch (Exception e) {
                Log.e(TAG, "File write failed");
            }

            /*
             * The following code creates a file in the AVD's internal storage and stores a file.
             *
             * For more information on file I/O on Android, please take a look at
             * http://developer.android.com/training/basics/data-storage/files.html
             */

            return;
        }
    }

    private class ClientTask extends AsyncTask<String, Void, Void>{
        @Override
        protected Void doInBackground(String... msgs){
            //try{

            String remoteport = msgs[1];
                //Log.v("remoteport", remoteport);
            String[] ports = new String[]{REMOTE_PORT0,REMOTE_PORT1,REMOTE_PORT2,REMOTE_PORT3,REMOTE_PORT4};

            String msgToSend = msgs[0];
            Log.v("msgToSend", msgToSend);

            Log.v("port number", ports[0]);
            SocketCreate sc = new SocketCreate(msgToSend,ports[0]);
            ScoketCreateRunnable scc = new ScoketCreateRunnable(sc);
            Thread t1 = new Thread(scc);
            t1.start();
            t1.setPriority(1);

            Log.v("port number", ports[1]);
            SocketCreate sc1 = new SocketCreate(msgToSend,ports[1]);
            ScoketCreateRunnable scc1 = new ScoketCreateRunnable(sc1);
            Thread t2 = new Thread(scc1);
            t2.start();
            t2.setPriority(2);

            Log.v("port number", ports[2]);
            SocketCreate sc2 = new SocketCreate(msgToSend,ports[2]);
            ScoketCreateRunnable scc2 = new ScoketCreateRunnable(sc2);
            Thread t3 = new Thread(scc2);
            t3.start();
            t3.setPriority(3);

            Log.v("port number", ports[3]);
            SocketCreate sc3 = new SocketCreate(msgToSend,ports[3]);
            ScoketCreateRunnable scc3 = new ScoketCreateRunnable(sc3);
            Thread t4 = new Thread(scc3);
            t4.start();
            t4.setPriority(4);

            Log.v("port number", ports[0]);
            SocketCreate sc4 = new SocketCreate(msgToSend,ports[4]);
            ScoketCreateRunnable scc4 = new ScoketCreateRunnable(sc4);
            Thread t5 = new Thread(scc4);
            t5.start();
            t5.setPriority(5);

            return null;
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.activity_group_messenger, menu);
        return true;
    }

    public class ScoketCreateRunnable implements Runnable{

        String msg;
        String port;
        SocketCreate socket1 ;

        ScoketCreateRunnable(SocketCreate socket){
            socket1 = socket;
        }

        public void run() {
            socket1.sendData();
        }
    }

    public class SocketCreate{
        String msg;
        String port;
        Socket s ;

        SocketCreate(String message, String ports) {
            msg = message;
            port = ports;
            Log.v("Socket Create", msg);
        }

        public void sendData() {
            synchronized (test) {
                try {
                    Log.v("Send data", msg);
                    if (port!=null) {
                        s = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}), Integer.parseInt(port));
                        Log.v("msgToSend", msg);
                        Log.v("port number", port);
                        Log.v("OUTPUT STREAM OPENED", msg);
                        ObjectOutputStream oos1 = new ObjectOutputStream(s.getOutputStream());
                        Log.v("msgToSendInsideSync", msg);
                        oos1.writeObject(msg);
                        oos1.close();
                        s.close();
                    }
                } catch (IOException e) {
                    Log.e("sendData", e.getStackTrace().toString());
                }
            }
        }
    }
}
